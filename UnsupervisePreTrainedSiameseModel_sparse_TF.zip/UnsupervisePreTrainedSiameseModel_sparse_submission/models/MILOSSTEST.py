import tensorflow as tf

def mutual_information_loss(learned_node_features_from, learned_node_features_to):
    """
    Compute mutual information-based loss between two sets of node embeddings.

    Args:
        learned_node_features_from: Tensor of shape (batch_size, num_nodes, embedding_dim).
        learned_node_features_to: Tensor of shape (batch_size, num_nodes, embedding_dim).

    Returns:
        loss: Scalar Tensor representing the mutual information-based loss.
    """
    # Ensure the input tensors have the same shape
    assert learned_node_features_from.shape == learned_node_features_to.shape

    # Flatten the embeddings for easier computation
    batch_size = tf.shape(learned_node_features_from)[0]
    num_nodes = tf.shape(learned_node_features_from)[1]
    embedding_dim = tf.shape(learned_node_features_from)[2]

    # Reshape embeddings to (batch_size * num_nodes, embedding_dim)
    embeddings_from = tf.reshape(learned_node_features_from, [-1, embedding_dim])
    embeddings_to = tf.reshape(learned_node_features_to, [-1, embedding_dim])

    # Compute the joint distribution (dot product between embeddings)
    joint_distribution = tf.matmul(embeddings_from, embeddings_to, transpose_b=True)  # Shape: (batch_size * num_nodes, batch_size * num_nodes)

    # Normalize the joint distribution to make it a valid probability distribution
    joint_distribution = tf.nn.softmax(joint_distribution, axis=-1)

    # Compute the marginal distributions by summing over rows and columns
    marginal_from = tf.reduce_sum(joint_distribution, axis=1, keepdims=True)  # Shape: (batch_size * num_nodes, 1)
    marginal_to = tf.reduce_sum(joint_distribution, axis=0, keepdims=True)    # Shape: (1, batch_size * num_nodes)

    # Compute the product of marginal distributions
    product_marginals = tf.matmul(marginal_from, marginal_to)  # Shape: (batch_size * num_nodes, batch_size * num_nodes)

    # Avoid log(0) by adding a small epsilon
    epsilon = 1e-10
    joint_distribution = joint_distribution + epsilon
    product_marginals = product_marginals + epsilon

    # Compute the mutual information (MI) using the formula:
    # MI = E_{joint} [log(joint) - log(product_marginals)]
    mi = tf.reduce_sum(joint_distribution * (tf.log(joint_distribution) - tf.log(product_marginals)))

    # Maximizing MI is equivalent to minimizing the negative MI
    loss = -mi

    return loss



def contrastive_loss(y_true, y_pred, margin=1.0):
    """
    Contrastive loss function for Siamese GNNs.

    Args:
        y_true: Tensor of shape (batch_size,), containing binary labels (1 for similar pairs, 0 for dissimilar pairs).
        y_pred: Tensor of shape (batch_size, 2 * embedding_dim), containing concatenated embeddings of the two graphs/nodes.
        margin: Margin for the contrastive loss (default: 1.0).

    Returns:
        loss: Scalar Tensor representing the contrastive loss.
    """
    # Split the concatenated embeddings into two parts
    embedding_1, embedding_2 = tf.split(y_pred, num_or_size_splits=2, axis=1)

    # Compute the Euclidean distance between the embeddings
    distance = tf.sqrt(tf.reduce_sum(tf.square(embedding_1 - embedding_2), axis=1))

    # Compute the contrastive loss
    loss = y_true * tf.square(distance) + (1 - y_true) * tf.square(tf.maximum(0.0, margin - distance))

    # Average the loss over the batch
    loss = tf.reduce_mean(loss)

    return loss
if __name__ == '__main__':
    # Example inputs
    batch_size = 32
    num_nodes = 10
    embedding_dim = 16

    # Random embeddings
    learned_node_features_from = tf.random.normal([batch_size, num_nodes, embedding_dim])
    learned_node_features_to = tf.random.normal([batch_size, num_nodes, embedding_dim])

    # Compute mutual information loss
    loss = mutual_information_loss(learned_node_features_from, learned_node_features_to)
    contloss = contrastive_loss(learned_node_features_from, learned_node_features_to)

    # Start a TensorFlow session to evaluate the loss
    with tf.Session() as sess:
        loss_value = sess.run(loss)
        print("Mutual Information Loss:", loss_value)
        print("Contrastive Loss:", sess.run(contloss))
