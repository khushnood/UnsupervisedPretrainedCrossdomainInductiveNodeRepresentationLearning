import tensorflow as tf
#from models import GraphConv,GlobalSumPool
from pathlib import Path
import sys
PROJECT_ROOT = Path(__file__).resolve().parent.parent
utils_path = PROJECT_ROOT / "models"
sys.path.append(str(utils_path))
from GraphConv import GraphConv
from GlobalSumPool import GlobalSumPool

class SpectralPoolingGNN(tf.keras.layers.Layer):
    def __init__(self, input_dim, hidden_dim, output_dim, num_pool_layers):
        super().__init__()
        self.conv_layers = [
            GraphConv(hidden_dim, activation="relu") for _ in range(num_pool_layers)
        ]
        initializer = tf.keras.initializers.VarianceScaling(scale=2.0, mode='fan_in', distribution='truncated_normal')
        self.pool_layers = [GlobalSumPool() for _ in range(num_pool_layers - 1)]
        self.dense_layers = [
            tf.keras.layers.Dense(hidden_dim, activation="relu",kernel_initializer=initializer) for _ in range(num_pool_layers - 1)
        ]
        self.output_layer = tf.keras.layers.Dense(output_dim, activation="relu")

        #self.dense_layer = tf.keras.layers.Dense(10, kernel_initializer=initializer)  # Apply initializer


    def call(self, inputs, training=False):
        x, a = inputs
        for conv, pool, dense in zip(self.conv_layers, self.pool_layers, self.dense_layers):
            x = conv([x, a])
            if pool is not None:
                x = pool(inputs)
                #x = tf.keras.layers.Reshape((10, 1))(x)
                x = dense(x)
        return self.output_layer(x)

# Example usage
model = SpectralPoolingGNN(10, 64, 5, 2)
x = tf.ones([10, 10])
a = tf.eye(10)
output = model([x, a])
