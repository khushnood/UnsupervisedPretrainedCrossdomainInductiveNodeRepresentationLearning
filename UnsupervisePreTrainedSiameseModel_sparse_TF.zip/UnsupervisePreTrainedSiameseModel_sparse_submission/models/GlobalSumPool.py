import tensorflow as tf
#from spektral.layers import GlobalSumPool

class GlobalSumPool(tf.keras.layers.Layer):
    """
    A global sum pooling layer for graphs.

    Pools a graph by summing up its node features.
    """

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    def call(self, inputs):
        x, a = inputs
        return tf.math.reduce_sum(x, axis=1)  # Sum node features along the first axis
