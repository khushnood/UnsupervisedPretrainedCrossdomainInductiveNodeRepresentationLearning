import tensorflow as tf
from tensorflow.keras.layers import Layer
import numpy as np

# Ensure TensorFlow 2.x behavior
tf.compat.v1.disable_v2_behavior()

# Define the PGNNLayer (dense-compatible)
class PGNNLayer(Layer):
    """
    Position-aware Graph Neural Network (P-GNN) Layer.
    Implements the P-GNN architecture from the ICML 2019 paper.
    """
    def __init__(self, out_features, input_dim, num_anchors=8, dropout=0.6, alpha=0.2):
        super(PGNNLayer, self).__init__()
        self.out_features = out_features
        self.input_dim = input_dim  # Input feature dimension
        self.num_anchors = num_anchors
        self.dropout = dropout
        self.alpha = alpha

        # Weight matrices for feature transformation
        self.W = self.add_weight(
            shape=(input_dim, out_features),  # Fully specified shape
            initializer="glorot_uniform",
            trainable=True,
            name="W"
        )

        # Weight matrices for anchor-based attention
        self.a = self.add_weight(
            shape=(2 * out_features, 1),  # Fully specified shape
            initializer="glorot_uniform",
            trainable=True,
            name="a"
        )

        # LeakyReLU activation
        self.leakyrelu = tf.keras.layers.LeakyReLU(alpha=alpha)

    def call(self, input, adj, anchor_indices):
        """
        Forward pass for the P-GNN layer.

        Args:
            input (tf.Tensor): Input features of shape (N, F).
            adj (tf.Tensor): Adjacency matrix of shape (N, N).
            anchor_indices (tf.Tensor): Indices of anchor nodes of shape (num_anchors,).

        Returns:
            tf.Tensor: Output features of shape (N, out_features).
        """
        N = tf.shape(input)[0]  # Number of nodes

        # Feature transformation
        h = tf.matmul(input, self.W)  # Shape: (N, out_features)

        # Compute attention scores between nodes and anchors
        h_anchors = tf.gather(h, anchor_indices)  # Shape: (num_anchors, out_features)
        h_self = tf.expand_dims(h, 1)  # Shape: (N, 1, out_features)
        h_neigh = tf.expand_dims(h_anchors, 0)  # Shape: (1, num_anchors, out_features)
        a_input = tf.concat([h_self + h_neigh, h_self - h_neigh], axis=-1)  # Shape: (N, num_anchors, 2 * out_features)
        e = self.leakyrelu(tf.squeeze(tf.matmul(a_input, self.a), axis=-1))  # Shape: (N, num_anchors)

        # Apply masked attention
        zero_vec = -9e15 * tf.ones_like(e)
        adj_anchors = tf.gather(adj, anchor_indices, axis=1)  # Use tf.gather for tensor indexing
        attention = tf.where(adj_anchors > 0, e, zero_vec)  # Mask out non-edges
        attention = tf.nn.softmax(attention, axis=1)  # Normalize attention scores
        attention = tf.nn.dropout(attention, rate=self.dropout)  # Apply dropout

        # Aggregate features using anchor-based attention
        h_prime = tf.matmul(attention, h_anchors)  # Shape: (N, out_features)

        return h_prime

# Define the GATLayer (dense-compatible)
class GATLayer(tf.keras.layers.Layer):
    def __init__(self, out_features, dropout=0.6, alpha=0.2, concat=True):
        super(GATLayer, self).__init__()
        self.dropout = dropout
        self.alpha = alpha
        self.concat = concat
        self.out_features = out_features

        # Xavier initialization for weights
        self.W = tf.keras.layers.Dense(
            out_features, use_bias=True, kernel_initializer="glorot_uniform"
        )
        self.a = tf.keras.layers.Dense(
            1, use_bias=True, kernel_initializer="glorot_uniform"
        )

        # LeakyReLU activation
        self.leakyrelu = tf.keras.layers.LeakyReLU(alpha=alpha)

    def call(self, input, Adj):
        # Linear transformation
        h = self.W(input)  # Shape: (N, out_features)
        N = tf.shape(h)[0]  # Number of nodes

        # Attention mechanism
        # Compute attention scores for all pairs of nodes
        h_self = tf.expand_dims(h, 1)  # Shape: (N, 1, out_features)
        h_neigh = tf.expand_dims(h, 0)  # Shape: (1, N, out_features)
        a_input = tf.concat([h_self + h_neigh, h_self - h_neigh], axis=-1)  # Shape: (N, N, 2 * out_features)
        e = self.leakyrelu(tf.squeeze(self.a(a_input), axis=-1))  # Shape: (N, N)

        # Apply masked attention
        zero_vec = -9e15 * tf.ones_like(e)
        attention = tf.where(Adj > 0, e, zero_vec)  # Mask out non-edges
        attention = tf.nn.softmax(attention, axis=1)  # Normalize attention scores
        attention = tf.nn.dropout(attention, self.dropout)  # Apply dropout

        # Aggregate features
        h_prime = tf.matmul(attention, h)  # Shape: (N, out_features)

        # Apply final activation
        if self.concat:
            return tf.nn.elu(h_prime)  # ELU activation for concatenation
        else:
            return h_prime  # No activation for mean aggregation

# Define the DynGraphEmbeddingSiam model (dense-compatible)
class DynGraphEmbeddingSiam:
    def __init__(self, inputShape, output_dimension, num_anchors=8,concat=False, useAttention = True):
        self.dimension = output_dimension
        self.hiddenDim = 64
        self.feature_dim = inputShape
        self.num_anchors = num_anchors
        self.concat =concat
        self.useAttention = useAttention
        self.gat_layer = GATLayer(out_features=output_dimension)

        # P-GNN layer for position-aware processing
        self.pgnn_layer = PGNNLayer(out_features=output_dimension, input_dim=inputShape, num_anchors=num_anchors)

        # Placeholders for dense inputs
        self.inputs_all = tf.compat.v1.placeholder(tf.float32, shape=[None, inputShape + 2 * num_nodes], name="inputs_all")
        self.labels = tf.compat.v1.placeholder(tf.float32, shape=[None, None], name="labels")

        # Model weights
        self.w1_f = tf.compat.v1.get_variable("W1", shape=(inputShape, self.hiddenDim), initializer=tf.glorot_uniform_initializer())
        self.whidden = tf.compat.v1.get_variable("Wout", shape=(self.hiddenDim, inputShape), initializer=tf.glorot_uniform_initializer())
        self.embeddings = tf.compat.v1.get_variable("embeddings", shape=(inputShape, output_dimension), initializer=tf.glorot_uniform_initializer())
        self.shared = tf.keras.layers.Dense(output_dimension, activation='relu', trainable=True)
        self.denseLayer2 = tf.keras.layers.Dense(output_dimension, activation='relu', trainable=True)

        # Forward pass
        self.output = self.call(self.inputs_all)

        # Loss function
        self.loss = pmi_loss_function(self.labels, self.output)

        # Optimizer
        self.optimizer = tf.compat.v1.train.AdamOptimizer(learning_rate=1e-5).minimize(self.loss)
        self.layer_norm1 = tf.keras.layers.LayerNormalization(epsilon=1e-6)
        self.layer_norm2 = tf.keras.layers.LayerNormalization(epsilon=1e-6)
        self.layer_norm3 = tf.keras.layers.LayerNormalization(epsilon=1e-6)
        self.layer_norm4 = tf.keras.layers.LayerNormalization(epsilon=1e-6)

    def GNN_forward_NL(self, A_hat, X, W):
        """
        GNN forward pass with Layer Normalization.
        """
        temp = tf.matmul(X, W)
        forward = tf.matmul(A_hat, temp)
        return tf.nn.relu(forward)

    def call(self, inputs_all):
        """
        Forward pass for the DynGraphEmbeddingSiam layer.

        Args:
            inputs_all (tf.Tensor): Concatenated input features and Laplacian adjacency matrix.

        Returns:
            tf.Tensor: Normalized output features.
        """
        # Split input into node features and Laplacian adjacency matrix
        X, Lapla_Adj = tf.split(inputs_all, [self.feature_dim, (int(inputs_all.shape[1]) - self.feature_dim)], axis=-1)
        A_hat, Adj = tf.split(Lapla_Adj, num_or_size_splits=2, axis=-1)

        # Randomly select anchor nodes
        anchor_indices = tf.random.uniform((self.num_anchors,), maxval=tf.shape(X)[0], dtype=tf.int32)

        # Perform two forward passes
        output1 = self.forwardCall(X, A_hat, Adj, self.w1_f, anchor_indices)
        output2 = self.forwardCall(X, A_hat, Adj, self.w1_f, anchor_indices)

        # Concatenate outputs and normalize
        return tf.concat([output1, output2], axis=-1)

    def forwardCall(self, X, A_hat, Adj, w, anchor_indices):
        """
        Forward pass for a single branch of the DynGraphEmbeddingSiam layer.

        Args:
            X (tf.Tensor): Node features.
            A_hat (tf.Tensor): Normalized adjacency matrix.
            Adj (tf.Tensor): Adjacency matrix.
            w (tf.Tensor): Trainable weight matrix.
            anchor_indices (tf.Tensor): Indices of anchor nodes.

        Returns:
            tf.Tensor: Output features.
        """
        # GNN forward pass with Layer Normalization
        H_1 = (self.GNN_forward_NL(A_hat, X, w))
        H_2 = (self.GNN_forward_NL(A_hat, H_1, self.whidden))
        H_3 = (self.GNN_forward_NL(A_hat, H_2, self.embeddings))

        # Ensure H_3 has the same shape as H_2
        if H_3.shape[-1] != H_2.shape[-1]:
            H_3 = tf.keras.layers.Dense(H_2.shape[-1])(H_3)

        # Add H_3 and H_2
        H_3 = H_3 + H_2

        # Apply GAT and P-GNN if attention is enabled
        if hasattr(self, 'useAttention') and self.useAttention:
            # GAT-based attention
            H_gat = self.gat_layer(X, Adj)
            # P-GNN-based attention
            H_pgnn = self.pgnn_layer(X, Adj, anchor_indices)
            # Combine GAT and P-GNN outputs
            H_4 = (H_gat + H_pgnn + self.denseLayer2(H_3))
            output = tf.concat([H_1, H_2, H_3, H_4], axis=1) if self.concat else H_4
        else:
            output = tf.concat([H_1, H_2, H_3], axis=1) if self.concat else H_3

        # Shared dense layer and normalization
        outputWithShared = self.shared(output)
        return tf.nn.l2_normalize(outputWithShared, axis=-1)

# Dummy PMI loss function
def pmi_loss_function(labels, y_pred, alpha=100.0, beta=100.0, margin=1.0):
    """
    Combined PMI-based and contrastive loss for Siamese GNNs.

    Args:
        labels: Tensor of shape (batch_size, num_nodes, num_nodes, 2), containing ground truth PMI values and binary labels.
        y_pred: Tensor of shape (batch_size, num_nodes, 2 * embedding_dim), containing predicted node embeddings.
        alpha: Weight for PMI-based loss.
        beta: Weight for contrastive loss.
        margin: Margin for the contrastive loss (default: 1.0).

    Returns:
        loss: Scalar Tensor representing the combined loss.
    """
    # Split the predicted embeddings
    learned_node_features_from, learned_node_features_to = tf.split(y_pred, num_or_size_splits=2, axis=-1)

    # Split the labels into ground truth PMI values and binary labels
    y_true, y_true_class = tf.split(labels, num_or_size_splits=2, axis=-1)

    # Compute the prediction score (dot product between embeddings)
    prediction_score = tf.matmul(learned_node_features_from, learned_node_features_to, transpose_b=True)

    epsilon = 1e-7  # Small epsilon to avoid NaN

    # Compute the KL divergence loss
    lossKL = tf.keras.losses.kullback_leibler_divergence(y_true, prediction_score)

    # Mask for positive and negative labels
    mask_label_1 = tf.cast(tf.greater(y_true, 0.0), dtype=tf.float32)  # Positive pairs
    mask_label_0 = 1 - mask_label_1  # Negative pairs

    # Weighted energy terms
    eng_pos = lossKL * mask_label_1
    eng_neg = lossKL * mask_label_0

    # Improved energy term
    energy = tf.square(eng_pos) + tf.exp(-eng_neg)

    # PMI-based loss
    pmiLoss = energy

    # Contrastive Loss
    squared_diff = tf.square(learned_node_features_from - learned_node_features_to)

    # Compute the Euclidean distance with numerical stability
    distance = tf.sqrt(tf.reduce_sum(squared_diff, axis=1) + epsilon)

    # Compute the contrastive loss
    contrastive_loss = y_true_class * tf.square(distance) + (1 - y_true_class) * tf.square(tf.maximum(0.0, margin - distance))

    # Combine the losses with explicit weighting
    combined_loss = alpha * tf.reduce_mean(pmiLoss) + beta * tf.reduce_mean(contrastive_loss)

    return combined_loss

# Custom training loop
def train_model(model, inputs_all, labels, num_epochs, batch_size):
    # Disable eager execution for TensorFlow 2.x compatibility
    tf.compat.v1.disable_v2_behavior()

    # Create a TensorFlow session
    with tf.compat.v1.Session() as sess:
        sess.run(tf.compat.v1.global_variables_initializer())

        # Evaluate labels to a NumPy array
        labels_np = labels.eval(session=sess)

        for epoch in range(num_epochs):
            # Get a batch of data
            batch_inputs, batch_labels = inputs_all, labels_np
            #batch_inputs, batch_labels = get_batch(inputs_all, labels, batch_size, sess)

            # Create feed dictionary
            feed_dict = {
                model.inputs_all: batch_inputs,
                model.labels: batch_labels  # Use the NumPy array here
            }

            # Run the session
            loss, _ = sess.run([model.loss, model.optimizer], feed_dict=feed_dict)
            print(f"Epoch {epoch + 1}, Loss: {loss}")
# Test case
def get_batch(data, labels, batch_size, session):
    """
    Get a batch of data from dense inputs.
    """
    num_samples = data.shape[0]
    indices = np.random.choice(num_samples, batch_size, replace=False)

    # Convert NumPy array indices to TensorFlow tensor
    indices_tf = tf.convert_to_tensor(indices, dtype=tf.int32)

    # Gather the corresponding data and labels
    batch_data = tf.gather(data, indices_tf)
    batch_labels = tf.gather(labels, indices_tf)

    # Evaluate the tensors to get NumPy arrays
    batch_data_np = batch_data.eval(session=session)
    batch_labels_np = batch_labels.eval(session=session)

    return batch_data_np, batch_labels_np


if __name__ == '__main__':
    # Define model parameters
    inputShape = 32  # Input feature dimension
    output_dimension = 16  # Output feature dimension
    num_nodes = 10  # Number of nodes in the graph
    num_epochs = 20  # Number of training epochs
    batch_size = 2  # Batch size
    num_anchors = 1  # Number of anchor nodes

    # Create dense input features (X) and adjacency matrices (A_hat, Adj)
    X = np.random.rand(num_nodes, inputShape)  # Dense input features
    A_hat = np.random.rand(num_nodes, num_nodes)  # Dense A_hat adjacency
    Adj = np.random.rand(num_nodes, num_nodes)  # Dense Adj adjacency

    # Concatenate X, A_hat, and Adj into a single dense tensor
    inputs_all = np.concatenate([X, A_hat, Adj], axis=1)

    # Dummy PMI values and labels
    PMI_values = np.random.rand(num_nodes, num_nodes)  # Dummy PMI values
    PMI_values_tensor = tf.convert_to_tensor(PMI_values, dtype=tf.float32)
    PMI_values_tensor_class = tf.cast(PMI_values > 0, dtype=tf.float32)  # Fix: Cast boolean to float32
    labels = tf.concat([PMI_values_tensor, PMI_values_tensor_class], axis=-1)

    # Create the DynGraphEmbeddingSiam model
    model = DynGraphEmbeddingSiam(inputShape, output_dimension, num_anchors=num_anchors)

    # Train the model using a custom training loop
    # Train the model using a custom training loop
    train_model(model, inputs_all, labels, num_epochs, batch_size)
