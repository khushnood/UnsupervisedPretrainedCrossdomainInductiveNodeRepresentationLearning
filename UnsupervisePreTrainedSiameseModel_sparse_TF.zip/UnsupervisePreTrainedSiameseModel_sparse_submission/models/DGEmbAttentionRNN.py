import tensorflow as tf
from tensorflow.keras.layers import Input, Lambda, Dense, Concatenate, Activation
from tensorflow.keras import regularizers
from tensorflow.keras.models import Model
from models.DotProductAttention import DotProductAttention
class MultiHeadAttentionRNN(tf.Module):
    def __init__(self, num_hiddens, num_heads, dropout=0.0, bias=False, **kwargs):
        super().__init__()
        self.num_heads = num_heads
        self.attention = DotProductAttention(dropout)
        self.W_q = tf.keras.layers.Dense(num_hiddens, use_bias=bias)
        self.W_k = tf.keras.layers.Dense(num_hiddens, use_bias=bias)
        self.W_v = tf.keras.layers.Dense(num_hiddens, use_bias=bias)
        self.W_o = tf.keras.layers.Dense(num_hiddens, use_bias=bias)

    def call(self, queries, keys, values, valid_lens, mask=None):
        queries = self.transpose_qkv(self.W_q(queries))
        keys = self.transpose_qkv(self.W_k(keys))
        values = self.transpose_qkv(self.W_v(values))

        if valid_lens is not None:
           # valid_lens = tf.repeat(valid_lens, repeats=self.num_heads, axis=0)
            valid_lens = tf.tile(valid_lens[:, :, tf.newaxis], [1, 1, self.num_heads])


        output, attention_weights = self.attention.call(queries, keys, values, mask)

        output_concat = self.transpose_output(output)
        return self.W_o(output_concat)

    def transpose_qkv(self, X):
        #X = tf.reshape(X, shape=(X.shape[0], X.shape[1], self.num_heads, -1))
        X = tf.reshape(X, shape=(-1, X.shape[1], self.num_heads, X.shape[-1] // self.num_heads))


        X = tf.transpose(X, perm=(0, 2, 1, 3))
        return tf.reshape(X, shape=(-1, X.shape[2], X.shape[3]))

    def transpose_output(self,X):
        X = tf.reshape(X, shape=(-1, self.num_heads, X.shape[1], X.shape[2]))
        X = tf.transpose(X, perm=(0, 2, 1, 3))
        return tf.reshape(X, shape=(-1, X.shape[1], X.shape[2] * X.shape[3]))



    def transpose_output_working(self, X):
         #X = tf.transpose(X, perm=(0, 2, 1, 3))
         X =tf.reshape(X, shape=(-1, self.num_heads, tf.reduce_prod(X.shape[2:])))

         return X

    def transpose_output_old(self, X):
        """Reverse the operation of transpose_qkv."""
        X = tf.reshape(X, shape=(-1, self.num_heads, X.shape[1], X.shape[2]))
        X = tf.transpose(X, perm=(0, 2, 1, 3))
        return tf.reshape(X, shape=(X.shape[0], X.shape[1], -1))

if __name__ == '__main__':

    # Example usage
    input_shape = [2, 51, 256]
    inputs = Input(shape=input_shape)
    lmda_lyr1 = Lambda(lambda x: x[:, 0, :, :], output_shape=input_shape[1:])(inputs)
    lmda_lyr2 = Lambda(lambda x: x[:, 1, :, :], output_shape=input_shape[1:])(inputs)

    num_heads = 4
    latent_dim = 256
    d_model = latent_dim
    attention_layer = MultiHeadAttentionRNN(d_model, num_heads, 0.5)

    # You should have valid_lens defined according to your task, otherwise, set it to None
    valid_lens = tf.reduce_sum(tf.ones_like(lmda_lyr1), axis=-1)

    attn_output1 = attention_layer.call(values=lmda_lyr1,
                                        keys=lmda_lyr1,
                                        queries=lmda_lyr2,
                                        valid_lens=valid_lens,
                                        mask=None)
    attn_output2 = attention_layer.call(values=lmda_lyr1,
                                        keys=lmda_lyr1,
                                        queries=lmda_lyr2,
                                        valid_lens=valid_lens,
                                        mask=None)

    concat_lyr = Concatenate(axis=-1)([attn_output1, attn_output2])
    fc_lyr1 = Dense(latent_dim, activation='tanh', kernel_regularizer=regularizers.l2(0.01))(concat_lyr)
    fc_lyr2 = Dense(1)(fc_lyr1)
    soft_lyr = Activation('sigmoid')(fc_lyr2)
    reshaped_output = Lambda(lambda x: x[:, -1])(soft_lyr)
    model = Model(inputs, reshaped_output)
    model.compile(optimizer='Adam', loss='binary_crossentropy', metrics=['accuracy'])

    # Sample data and labels
    nump_samples = 100
    data = tf.random.uniform((nump_samples, 2, 51, 256), minval=0, maxval=1)
    labels = tf.random.uniform((nump_samples, 1), minval=0, maxval=2, dtype=tf.int32)
    labels = tf.where(labels == 0, 0, 1)

    print(f"data size: {data.shape} label size: {labels.shape}")

    # Assuming you have proper training data, you can train the model
    model.fit(data, labels, epochs=10, batch_size=32, steps_per_epoch=32)
