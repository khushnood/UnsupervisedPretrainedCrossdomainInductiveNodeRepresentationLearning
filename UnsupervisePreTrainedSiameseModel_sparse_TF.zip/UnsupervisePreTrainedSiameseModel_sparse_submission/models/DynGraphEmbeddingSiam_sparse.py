import tensorflow as tf
from tensorflow.keras.layers import Layer
import numpy as np
from models.gin_layer_sparse import GIN

from scipy.sparse import csr_matrix
from scipy.sparse.csgraph import shortest_path
from models.PGNNLayer_SPARSE import PGNN
from utils.GNN_util_tf import pmi_loss_function
from utils.GNN_util_tf import pmi_loss_function_sparse_with_regul


class SparseDenseLayer(tf.keras.layers.Layer):
    def __init__(self, out_features):
        super(SparseDenseLayer, self).__init__()
        self.out_features = out_features
        self.kernel = None
        self.bias = None

    def build(self, input_shape):
        # Ensure input_shape[-1] is defined
        if input_shape[-1] is None:
            raise ValueError("The last dimension of the input shape must be defined.")

        # Define weights for the dense layer
        self.kernel = self.add_weight(
            name="kernel",
            shape=(int(input_shape[-1]), self.out_features),
            initializer="glorot_uniform",
            trainable=True,
        )
        self.bias = self.add_weight(
            name="bias",
            shape=(self.out_features,),
            initializer="zeros",
            trainable=True,
        )

    def call(self, inputs):
        if isinstance(inputs, tf.SparseTensor):
            # Handle sparse inputs
            outputs = tf.sparse.sparse_dense_matmul(inputs, self.kernel)
        else:
            # Handle dense inputs
            outputs = tf.matmul(inputs, self.kernel)
        outputs = tf.nn.bias_add(outputs, self.bias)
        return outputs

class GATLayer(Layer):
    def __init__(self, out_features, dropout=0.5, alpha=0.2, concat=True):
        super(GATLayer, self).__init__()
        self.dropout = dropout
        self.alpha = alpha
        self.concat = concat
        self.out_features = out_features

        # Xavier initialization for weights
        self.W = SparseDenseLayer(out_features)
        self.a = SparseDenseLayer(1)

        # LeakyReLU activation
        self.leakyrelu = tf.keras.layers.LeakyReLU(alpha=alpha)

    def build(self, input_shape):
        # Ensure input_shape[-1] is defined
        if input_shape[-1] is None:
            raise ValueError("The last dimension of the input shape must be defined.")

        # Build sub-layers
        self.W.build(input_shape)
        self.a.build(input_shape)

    def call(self, input, Adj):
        """
        Forward pass for the GAT layer.

        Args:
            input (tf.SparseTensor): Sparse input features of shape (N, F).
            Adj (tf.SparseTensor): Sparse adjacency matrix of shape (N, N).

        Returns:
            tf.Tensor: Output features of shape (N, out_features).
        """
        # Linear transformation
        h = self.W(input)  # Shape: (N, out_features)
        N = tf.shape(h)[0]  # Number of nodes

        # Attention mechanism
        # Compute attention scores for all pairs of nodes
        h_self = tf.expand_dims(h, 1)  # Shape: (N, 1, out_features)
        h_neigh = tf.expand_dims(h, 0)  # Shape: (1, N, out_features)
        a_input = tf.concat([h_self + h_neigh, h_self - h_neigh], axis=-1)  # Shape: (N, N, 2 * out_features)
        e = self.leakyrelu(tf.squeeze(self.a(a_input), axis=-1))  # Shape: (N, N)

        # Apply masked attention
        zero_vec = -9e15 * tf.ones_like(e)
        adj_dense = tf.sparse.to_dense(Adj)  # Convert sparse adjacency to dense for masking
        attention = tf.where(adj_dense > 0, e, zero_vec)  # Mask out non-edges
        attention = tf.nn.softmax(attention, axis=1)  # Normalize attention scores
        attention = tf.nn.dropout(attention, rate=self.dropout)  # Apply dropout

        # Aggregate features
        h_prime = tf.matmul(attention, h)  # Shape: (N, out_features)

        # Apply final activation
        if self.concat:
            return tf.nn.elu(h_prime)  # ELU activation for concatenation
        else:
            return h_prime  # No activation for mean aggregation
# Convert dense tensor to sparse tensor
def convert_to_sparse(X):
    indices = tf.where(tf.not_equal(X, 0))
    values = tf.gather_nd(X, indices)
    dense_shape = tf.shape(X, out_type=tf.int64)
    return tf.SparseTensor(indices=indices, values=values, dense_shape=dense_shape)

def scipy_sparse_to_tf_sparse(A_hat_tensor, densShape):
    # Convert the sparse matrix to COO format
    coo = A_hat_tensor.tocoo()

    # Extract indices and values
    indices = np.column_stack((coo.row, coo.col))
    values = coo.data

    # Convert indices to int64
    indices = indices.astype(np.int64)
    values = tf.cast(values, dtype=tf.float32)

    # Create the SparseTensor
    tf_sparse = tf.SparseTensor(indices=indices, values=values, dense_shape=densShape)

    return tf_sparse

def GNN_forward_NL(self, A_hat, X, W):
    """
    Sparse-based forward pass for GNN.

    Args:
        A_hat: Sparse adjacency matrix of shape (num_nodes, num_nodes).
        X: Sparse feature matrix of shape (num_nodes, input_dim).
        W: Weight matrix of shape (input_dim, output_dim).

    Returns:
        tf.Tensor: Output features of shape (num_nodes, output_dim).
    """
    # Ensure A_hat and X are SparseTensors
    if not isinstance(A_hat, tf.SparseTensor):
        A_hat = tf.sparse.from_dense(A_hat)
    if not isinstance(X, tf.SparseTensor):
        X = tf.sparse.from_dense(X)
    # Reorder sparse tensors to ensure indices are sorted
    A_hat = tf.sparse.reorder(A_hat)
    X = tf.sparse.reorder(X)
    # Perform sparse-dense matrix multiplication: X * W
    temp = tf.sparse.sparse_dense_matmul(X, W)  # Shape: (num_nodes, output_dim)
    # Perform sparse-dense matrix multiplication: A_hat * temp
    forward = tf.sparse.sparse_dense_matmul(A_hat, temp)  # Shape: (num_nodes, output_dim)

    # Apply ReLU activation
    return tf.nn.relu(forward)
# Define the DynGraphEmbeddingSiam model (sparse-compatible)


class DynGraphEmbeddingSiam(Layer):
    def __init__(self, inputShape, output_dimension, concat=False, useAttention=True, num_anchors=8,layer_nums=4):
        super(DynGraphEmbeddingSiam, self).__init__()
        self.feature_dim = inputShape  # Input feature dimension
        self.output_dim = output_dimension
        self.concat = concat
        self.useAttention = useAttention
        self.num_anchors = num_anchors

        # Define trainable weights
        self.w1_f = self.add_weight(
            shape=(inputShape, 64),  # Example hidden dimension
            initializer='glorot_uniform',
            trainable=True,
            dtype=tf.float32,
            name='W1'
        )
        self.whidden = self.add_weight(
            shape=(64, inputShape),  # Example hidden dimension
            initializer='glorot_uniform',
            trainable=True,
            dtype=tf.float32,
            name='Wout'
        )
        self.embeddings = self.add_weight(
            shape=(inputShape, output_dimension),
            initializer='glorot_uniform',
            trainable=True,
            dtype=tf.float32,
            name='embeddings'
        )
        self.shared = tf.keras.layers.Dense(output_dimension, activation='relu', trainable=True,dtype=tf.float32)
        if not concat:
            self.emb_comb_weight1 = tf.Variable(0.25, trainable=True)
            self.emb_comb_weight2 = tf.Variable(0.25, trainable=True)
            self.emb_comb_weight3 = tf.Variable(0.25, trainable=True)


        # Layer Normalization layers
        self.layer_norm3 = tf.keras.layers.LayerNormalization(epsilon=1e-6,dtype=tf.float32)
        self.layer_norm4 = tf.keras.layers.LayerNormalization(epsilon=1e-6,dtype=tf.float32)

        # GAT layer for attention-based processing
        if useAttention:
            self.gat_layer = GATLayer(out_features=output_dimension)
            self.denseLayer2 = SparseDenseLayer(output_dimension)
            if not concat:
                self.emb_comb_weight4 = tf.Variable(0.25, trainable=True)


        self.pgnn_layer =PGNN(inputShape, inputShape, output_dimension, output_dimension, feature_pre=True, layer_num=1, dropout=True)

        #GIN layer for isophorphic encoding
        self.gin_layer=GIN(inputShape, output_dimension, num_layers=layer_nums, hidden=64)


    def call(self, inputs_all):
        """
        Forward pass for the DynGraphEmbeddingSiam layer.
        """
        # Ensure inputs_all is a SparseTensor



        X, A_hat, Adj, dist_max, dist_argmax = inputs_all

        # Randomly select anchor nodes
        anchor_indices = tf.random.uniform((self.num_anchors,), maxval=tf.shape(X)[0], dtype=tf.int32)

        # Perform two forward passes
        output1 = self.forwardCall(X, A_hat, Adj, self.w1_f, anchor_indices,dist_max, dist_argmax)
        output2 = self.forwardCall(X, A_hat, Adj, self.w1_f, anchor_indices,dist_max, dist_argmax)

        # Concatenate outputs and normalize
        return tf.concat([output1, output2], axis=-1)

    def forwardCall(self, X, A_hat, Adj, w, anchor_indices,dist_max, dist_argmax):
        """
        Forward pass for a single branch of the DynGraphEmbeddingSiam layer.
        """
        # Ensure X, A_hat, and Adj are SparseTensors
        if not isinstance(X, tf.SparseTensor):
            X = tf.sparse.from_dense(X)
        if not isinstance(A_hat, tf.SparseTensor):
            A_hat = tf.sparse.from_dense(A_hat)
        if not isinstance(Adj, tf.SparseTensor):
            Adj = tf.sparse.from_dense(Adj)

        # Reorder sparse tensors to ensure indices are sorted
        X = tf.sparse.reorder(X)
        A_hat = tf.sparse.reorder(A_hat)
        Adj = tf.sparse.reorder(Adj)

        # GNN forward pass with Layer Normalization
        H_1 = GNN_forward_NL(self, A_hat, X, w)  # Shape: (num_nodes, hidden_dim)
        H_2 = GNN_forward_NL(self, A_hat, H_1, self.whidden)  # Shape: (num_nodes, hidden_dim)

        # Ensure the output of GNN_forward_NL matches the shape of H_2
        H_3_input = GNN_forward_NL(self, A_hat, H_2, self.embeddings)  # Shape: (num_nodes, output_dim)
        if H_3_input.shape[-1] != H_2.shape[-1]:
            # Project H_3_input to match the shape of H_2
            projection_layer = tf.keras.layers.Dense(H_2.shape[-1], activation=None)
            H_3_input = projection_layer(H_3_input)

        H_3 = self.layer_norm3(H_3_input + H_2)  # Shape: (num_nodes, output_dim)
        edge_index= tf.transpose(Adj.indices)
        H_gin=self.gin_layer((X, edge_index, 32), training=True)


        pgnnData = {
        'x': X,  # Sparse node features (
        'dists_max': dist_max,  # Maximum distances (100 nodes)
        'dists_argmax': dist_argmax,  # Argument of maximum distances (100 nodes)
        'anchor_indices': anchor_indices
         }

        H_pgnn  = self.pgnn_layer(pgnnData, training=True)


        if self.useAttention:

            H_gat = self.gat_layer(X, Adj)  # Ensure gat_layer supports sparse inputs
            H_4 = self.layer_norm4(H_gat +  self.denseLayer2(H_3))  # Shape: (num_nodes, output_dim)
            output = tf.concat([H_gin, H_pgnn, H_3, H_4], axis=1) if self.concat else (self.emb_comb_weight1*H_gin + self.emb_comb_weight2*H_pgnn + self.emb_comb_weight3*H_3+self.emb_comb_weight4*H_4)
        else:
            output = tf.concat([H_gin, H_pgnn, H_3], axis=1) if self.concat else (self.emb_comb_weight1*H_gin + self.emb_comb_weight2*H_pgnn + self.emb_comb_weight3*H_3)

        # Shared dense layer and normalization
        outputWithShared = self.shared((output))  # Shape: (num_nodes, final_output_dim)
        return tf.nn.l2_normalize(outputWithShared, axis=-1)  # Normalize output



def train_model(model, inputs_all, labels, num_epochs, batch_size, patience=5):
    # Define the optimizer
    learning_rate=1e-5
    lr_schedule = tf.keras.optimizers.schedules.ExponentialDecay(
    initial_learning_rate=learning_rate,
    decay_steps=10000,  # Number of steps after which the learning rate decays
    decay_rate=0.9,     # Factor by which the learning rate decays
    staircase=True      # If True, decay in discrete intervals (step-wise)
)

    optimizer = tf.keras.optimizers.Adam(lr_schedule, beta_1=0.9, beta_2=0.999, epsilon=1e-07, amsgrad=True, name='Adam')


    # Initialize variables for early stopping
    best_loss = float('inf')  # Track the best loss
    wait = 0  # Counter for epochs without improvement
    best_weights = None  # To store the best model weights

    for epoch in range(num_epochs):
        with tf.GradientTape() as tape:
            # Forward pass
            outputs = model(inputs_all)
            # Compute loss
            loss = pmi_loss_function(labels, outputs)


        # Compute gradients
        gradients = tape.gradient(loss, model.trainable_variables)
        # Update weights
        optimizer.apply_gradients(zip(gradients, model.trainable_variables))

        # Print the loss for the current epoch
        print(f"Epoch {epoch + 1}, Loss: {loss.numpy()}")

        # Early stopping logic
        if loss < best_loss:
            best_loss = loss
            wait = 0  # Reset the wait counter
            best_weights = model.get_weights()  # Save the best weights
        else:
            wait += 1  # Increment the wait counter

        # Stop training if the loss hasn't improved for `patience` epochs
        if wait >= patience:
            print(f"Early stopping at epoch {epoch + 1} as loss hasn't improved for {patience} epochs.")
            break

    # Restore the best weights (if early stopping was triggered)
    if best_weights is not None:
        model.set_weights(best_weights)

    return model
# Test case
def get_batch(data, labels, batch_size):
    """
    Get a batch of data from sparse inputs.
    """
    num_samples = data.dense_shape[0]
    indices = np.random.choice(num_samples, batch_size, replace=False)

    # Gather sparse indices and values for the batch
    batch_indices = []
    batch_values = []
    for idx in indices:
        # Find all indices and values corresponding to the selected sample
        sample_indices = tf.where(tf.equal(data.indices[:, 0], idx))
        sample_values = tf.gather(data.values, sample_indices[:, 0])
        batch_indices.append(tf.gather(data.indices, sample_indices[:, 0]))
        batch_values.append(sample_values)

    # Concatenate the indices and values
    batch_indices = tf.concat(batch_indices, axis=0)
    batch_values = tf.concat(batch_values, axis=0)

    # Create a SparseTensor for the batch
    batch_dense_shape = tf.constant([batch_size, data.dense_shape[1]], dtype=tf.int64)
    batch_data = tf.SparseTensor(indices=batch_indices, values=batch_values, dense_shape=batch_dense_shape)

    # Reorder the sparse tensor indices
    batch_data = tf.sparse.reorder(batch_data)

    # Gather the corresponding labels
    batch_labels = tf.gather(labels, indices)

    return batch_data, batch_labels

#######################################################

def create_and_train_model(feature_tensor, Adj_tensor, A_hat_tensor, PMI_values, dist_max, dist_argmax, num_epochs,output_dimension):
    """
    Create and train the Siamese GNN model.

    Args:
        feature_tensor: Input feature tensor.
        Adj_tensor: Adjacency matrix tensor.
        A_hat_tensor: Normalized adjacency matrix tensor.
        PMI_values: PMI values tensor.
        num_epochs: Number of training epochs.

    Returns:
        Trained model.
    """
    num_nodes = feature_tensor.shape[0]
    inputShape = feature_tensor.shape[1]
    batch_size = 2


    X_indices = tf.where(feature_tensor != 0)   # Non-zero indices
    X_values = tf.gather_nd(feature_tensor, X_indices)   # Random values for non-zero indices
    X_sparse = tf.SparseTensor(indices=X_indices, values=X_values, dense_shape=(num_nodes, inputShape))
    X_sparse = tf.cast(X_sparse, dtype=tf.float32)
    A_hat_sparse = scipy_sparse_to_tf_sparse(A_hat_tensor, densShape=(num_nodes, num_nodes))
    Adj_sparse = scipy_sparse_to_tf_sparse(Adj_tensor,densShape=(num_nodes, num_nodes))

    inputs_all = ( X_sparse, A_hat_sparse, Adj_sparse, dist_max, dist_argmax)




    PMI_values_ind = tf.where(PMI_values > 0)  # Shape: (num_non_zero, 2)
    PMI_values_tensor = tf.gather_nd(PMI_values, PMI_values_ind)  # Shape: (num_non_zero,)
    PMI_values_sparse = tf.SparseTensor(
        indices=PMI_values_ind,
        values=PMI_values_tensor,
        dense_shape=(num_nodes, num_nodes)    )


    PMI_values_class_sparse =Adj_sparse
    PMI_values_sparse = tf.cast(PMI_values_sparse, dtype=tf.float32)
    PMI_values_class_sparse = tf.cast(PMI_values_class_sparse, dtype=tf.float32)
    labels = tf.sparse.concat(axis=-1, sp_inputs=[PMI_values_sparse, PMI_values_class_sparse])

    model = tf.keras.Sequential([DynGraphEmbeddingSiam(inputShape=inputShape, output_dimension=output_dimension)])

    # Train the model using a custom training loop
    return train_model(model, inputs_all, labels, num_epochs, batch_size)

if __name__ == '__main__':
    # Define model parameters
    inputShape = 32  # Input feature dimension
    output_dimension = 16  # Output feature dimension
    num_nodes = 100  # Number of nodes in the graph
    num_epochs = 50  # Number of training epochs
    batch_size = 2  # Batch size
    num_anchors = 8  # Number of anchor nodes

    # Create sparse input features (X) and adjacency matrices (A_hat, Adj)
    X_indices = tf.where(tf.random.uniform((num_nodes, inputShape)) > 0.5)  # Random non-zero indices
    X_values = tf.random.uniform((tf.shape(X_indices)[0],))  # Random values for non-zero indices
    X_sparse = tf.SparseTensor(indices=X_indices, values=X_values, dense_shape=(num_nodes, inputShape))

    # Sparse adjacency matrices (A_hat and Adj)
    A_hat_indices = tf.where(tf.random.uniform((num_nodes, num_nodes)) > 0.5)  # Random non-zero indices
    A_hat_values = tf.random.uniform((tf.shape(A_hat_indices)[0],))  # Random values for non-zero indices
    A_hat_sparse = tf.SparseTensor(indices=A_hat_indices, values=A_hat_values, dense_shape=(num_nodes, num_nodes))

    Adj_indices = tf.where(tf.random.uniform((num_nodes, num_nodes)) > 0.5)  # Random non-zero indices
    Adj_values = tf.random.uniform((tf.shape(Adj_indices)[0],))  # Random values for non-zero indices
    Adj_sparse = tf.SparseTensor(indices=Adj_indices, values=Adj_values, dense_shape=(num_nodes, num_nodes))

    # Concatenate X_sparse, A_hat_sparse, and Adj_sparse into a single sparse tensor
    inputs_all = tf.sparse.concat(axis=-1, sp_inputs=[X_sparse, A_hat_sparse, Adj_sparse])

    # Reorder the concatenated sparse tensor
    inputs_all = tf.sparse.reorder(inputs_all)
    print("X_sparse dense_shape:", X_sparse.dense_shape)
    print("A_hat_sparse dense_shape:", A_hat_sparse.dense_shape)
    print("Adj_sparse dense_shape:", Adj_sparse.dense_shape)

    # Debug the concatenated sparse tensor
    print("inputs_all indices:", inputs_all.indices.shape)
    print("inputs_all values:", inputs_all.values.shape)
    print("inputs_all dense_shape:", inputs_all.dense_shape)

    # Generate random PMI values and binary labels
    PMI_values = tf.random.uniform((num_nodes, num_nodes))  # Dummy PMI values (2D tensor)
    PMI_values_tensor_class = tf.cast(PMI_values > 0, dtype=tf.float32)  # Binary labels (2D tensor)

    # Find non-zero indices and values
    PMI_values_ind = tf.where(PMI_values > 0)  # Shape: (num_non_zero, 2)
    PMI_values_tensor = tf.gather_nd(PMI_values, PMI_values_ind)  # Shape: (num_non_zero,)

    # Create the SparseTensor for PMI values
    PMI_values_sparse = tf.SparseTensor(
        indices=PMI_values_ind,
        values=PMI_values_tensor,
        dense_shape=(num_nodes, num_nodes)
    )

    # Find non-zero indices for binary labels
    PMI_values_class_ind = tf.where(PMI_values_tensor_class > 0)  # Shape: (num_non_zero, 2)
    PMI_values_class_tensor = tf.gather_nd(PMI_values_tensor_class, PMI_values_class_ind)  # Shape: (num_non_zero,)

    # Create the SparseTensor for binary labels
    PMI_values_class_sparse = tf.SparseTensor(
        indices=PMI_values_class_ind,
        values=PMI_values_class_tensor,
        dense_shape=(num_nodes, num_nodes)
    )

    # Concatenate the two sparse tensors along the last axis
    labels = tf.sparse.concat(axis=-1, sp_inputs=[PMI_values_sparse, PMI_values_class_sparse])

    # Debug the labels sparse tensor
    print("labels indices:", labels.indices.shape)
    print("labels values:", labels.values.shape)
    print("labels dense_shape:", labels.dense_shape)

    # Create the DynGraphEmbeddingSiam model
    model = tf.keras.Sequential([DynGraphEmbeddingSiam(inputShape=inputShape, output_dimension=output_dimension)])

    # Train the model using a custom training loop
    train_model(model, inputs_all, labels, num_epochs, batch_size)
    pretrained_model_path = "path/to/save/weights"
    model.save_weights(pretrained_model_path)
    print(f"Model weights saved to {pretrained_model_path}")

