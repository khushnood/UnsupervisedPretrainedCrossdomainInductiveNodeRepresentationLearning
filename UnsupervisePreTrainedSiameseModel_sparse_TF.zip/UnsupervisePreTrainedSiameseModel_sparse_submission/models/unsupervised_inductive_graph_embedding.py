import os
from os.path import join

import metrics
import networkx as nx
from networkx import to_numpy_matrix, from_numpy_matrix
import numpy as np
from tqdm import tqdm
from node2vec import Node2Vec
from scipy.linalg import orthogonal_procrustes
import scipy.sparse as sp

# TensorFlow 2.5 imports
import tensorflow as tf
from tensorflow.keras import regularizers, layers
from tensorflow.keras.layers import Input, LSTM, GRU, Dense, Activation, Concatenate, Lambda, Dropout, Embedding
from tensorflow.keras.models import Model, Sequential
import loader
from models.task_model import TaskModel
from utils.graph_utils import get_graph_T, get_pivot_time, get_graph_times, multigraph2graph
from utils.general_utils import load_object, save_object
from utils.consts import TLP, NC, TLPXYZ
import gc

# Commented-out imports (ensure they are compatible if uncommented)
# from cogdl.models import build_model
# from cogdl import options
from argparse import Namespace

from utils.TimeHashing import create_vector_representation

from scipy.stats import ortho_group
from procrustes import orthogonal, rotational
import random, math
from scipy.stats import poisson

# Commented-out imports (ensure they are compatible if uncommented)
# from models.GraphAttentionModel import GraphAttentionLayer
# from tensorflow.contrib.rnn import LayerNormBasicLSTMCell  # Not available in TF 2.x
from scipy.sparse import csr_matrix

# TensorFlow 2.5 imports
from tensorflow.keras.layers import Input, Lambda, Dense, Concatenate, Activation
from tensorflow.keras.models import Model
import time as systime

from models.DGEmbAttentionRNN import MultiHeadAttentionRNN
from tensorflow.keras import regularizers
from tensorflow.keras.layers import Lambda, Dense, Concatenate, Activation
import pandas as pd
from joblib import Parallel, delayed

# Commented-out imports (ensure they are compatible if uncommented)
# from multiprocessing import Lock, Manager
from models.DynGraphEmbeddingSiam_sparse import DynGraphEmbeddingSiam

from utils.siamese_model_util import *
from models.DynGraphEmbeddingSiam_sparse import create_and_train_model

class UnsupervisedInductiveGNN(TaskModel):
    def __init__(self, graph_nx, task, dump_folder, test_size=0, align=True, model_name='prone', dataset_name='THCN',is_pretrained=False,is_tranfer_learning=False,model_path=None,num_cpu=1,*model_args):
        '''
        UnsupervisedInductiveGNN init
        Args:
            graph_nx: networkx - holding the temporal graph
            task: str - name of the task. either 'temporal_link_prediction' or 'node_classification'
            dump_folder: string - link to a dump folder of the graph dataset, in order for future runs to run faster
            test_size: folat - the wanted size of test_size
            align: bool - True if alignment is wanted, else False

        '''
        super(UnsupervisedInductiveGNN, self).__init__(task=task)

        self.dump_folder = dump_folder
        self.test_size = test_size
        self.align = align
        self.dataset_name=dataset_name

        self.model_name=model_name

        self.graph_nx = graph_nx
        times = get_graph_times(self.graph_nx)
        self.is_pretrained=is_pretrained
        self.is_tranfer_learning=is_tranfer_learning
        self.model_path=model_path
        self.num_cpu=num_cpu

        if self.task == TLP:
            self.pivot_time = self.calculate_pivot_time()
        else:
            self.pivot_time = times[-1]

        self.train_time_steps = times[times <= self.pivot_time]

        # initialize
        self.graph_nx = self.initialize()


    def get_dataset(self, train_skip=1):
        '''
        This function is responsible of creating the dataset of the wanted task from the given graph_nx. Wraps the
        function 'task_loader.load_task' for caching.
        Args:
            train_skip: float - ratio of the data we take for train. For example, if we have N possible
                                 samples in the given graph_nx, then we take only int(N/train_skip) samples for train.
                                 This is highly important in large graphs.
        Returns:
            X: dict - with keys 'train', 'test'. each value is a np.array of the dataset, where each entery is a sample
                      with the embeddings.
            y: dict - with keys 'train', 'test', each value is a np.array of the dataset, where y[key][i] is the label
                      of X[key][i] for the given task.
        '''
        # load task data
        task_data_path = join(self.dump_folder, f'{self.task}_dataset_{self.pivot_time}.data')
        if os.path.exists(task_data_path):
            X, y = load_object(task_data_path)
        else:
            X, y = loader.load_task(self.graph_nx, self.task, train_skip=1, pivot_time=self.pivot_time,
                                    test_size=self.test_size)
            save_object((X, y), task_data_path)

        X = {'train': X['train'][::train_skip], 'test': X['test'],'test_hist_nre':X['test_hist_nre'], 'test_rnd': X['test_rnd'],'test_induc_nre': X['test_induc_nre']}
        y = {'train': y['train'][::train_skip], 'test': y['test'],'test_hist_nre':y['test_hist_nre'], 'test_rnd': y['test_rnd'],'test_induc_nre': y['test_induc_nre']}

        return X, y



    @staticmethod
    def _get_model(task, input_shape, latent_dim=128, num_classes=1):
        '''
        Constructs and returns a model based on the specified task.

        Args:
            task: str - Name of the task, either 'temporal_link_prediction' or 'node_classification'.
            input_shape: tuple - Shape of a single input sample.
            latent_dim: int - Size of the latent dimension (default: 128).
            num_classes: int - Number of classes (relevant only for 'node_classification').

        Returns:
            keras.Model - A compiled Keras model for the specified task.

        Raises:
            ValueError: If the task is not recognized.
        '''
        if task == TLP:
            # Input layer
            inputs = Input(shape=input_shape)

            # Extract two slices from the input tensor
            slice_1 = Lambda(lambda x: x[:, 0, :, :], output_shape=input_shape[1:])(inputs)
            slice_2 = Lambda(lambda x: x[:, 1, :, :], output_shape=input_shape[1:])(inputs)

            # Ensure latent_dim is at least 128
            if latent_dim < 128:
                latent_dim = 128

            # Multi-head attention configuration
            d_model = int(latent_dim / 2)
            num_heads = 16
            attention_layer = MultiHeadAttentionRNN(d_model, num_heads, dropout=0.2)

            # Apply attention to both slices
            attn_output_1 = attention_layer.call(values=slice_1, keys=slice_1, queries=slice_1, valid_lens=None, mask=None)
            attn_output_2 = attention_layer.call(values=slice_2, keys=slice_2, queries=slice_2, valid_lens=None, mask=None)

            # Dense layers for attention outputs
            attn_output_1_dense = Dense(latent_dim, activation='relu')(attn_output_1)
            attn_output_2_dense = Dense(latent_dim, activation='relu')(attn_output_2)

            # Concatenate and apply fully connected layers
            concat_layer = Concatenate(axis=-1)([attn_output_1_dense, attn_output_2_dense])
            fc_layer_1 = Dense(latent_dim, activation='relu')(concat_layer)
            fc_layer_2 = Dense(1)(fc_layer_1)

            # Reshape and apply sigmoid activation
            reshaped_output = Lambda(lambda x: x[:, -1])(fc_layer_2)
            output = Activation('sigmoid')(reshaped_output)

            # Create and compile the model
            model = Model(inputs, output)
            model.compile(optimizer='Adam', loss='binary_crossentropy', metrics=['accuracy'])

        elif task == 'node_classification':
            # Input layer
            inputs = Input(shape=input_shape)

            # Extract two slices from the input tensor
            slice_1 = Lambda(lambda x: x[:, 0, :, :], output_shape=input_shape[1:])(inputs)
            slice_2 = Lambda(lambda x: x[:, 1, :, :], output_shape=input_shape[1:])(inputs)

            # LSTM layers
            lstm_layer = LSTM(latent_dim, return_sequences=False, activation='tanh', dropout=0.2)
            lstm_output_1 = lstm_layer(slice_1)
            lstm_output_2 = lstm_layer(slice_2)

            # Concatenate and apply fully connected layers
            concat_layer = Concatenate(axis=-1)([lstm_output_1, lstm_output_2])
            fc_layer_1 = Dense(latent_dim, activation='tanh', kernel_regularizer=regularizers.l2(0.01))(concat_layer)
            fc_layer_2 = Dense(num_classes)(fc_layer_1)

            # Apply softmax activation for classification
            output = Activation('softmax')(fc_layer_2)

            # Create and compile the model
            model = Model(inputs, output)
            model.compile(optimizer='Adam', loss='sparse_categorical_crossentropy', metrics=['sparse_categorical_accuracy'])

        else:
            raise ValueError(f"Unknown task: {task}. Supported tasks are 'temporal_link_prediction' and 'node_classification'.")

        return model


    def calculate_pivot_time(self):
        '''
        Calculate the pivot time that is needed in order to create a 'time_split_ratio' between train edges and
        test edges
        Returns:
            time step representing the pivot time step
        '''
        ratio2pivot = {}
        ratio2pivot_path = join(self.dump_folder, 'ratio2pivot.dict')
        if os.path.exists(ratio2pivot_path):
            ratio2pivot = load_object(ratio2pivot_path)
            if self.test_size in ratio2pivot:
                return ratio2pivot[self.test_size]
        pivot_time = get_pivot_time(self.graph_nx, self.test_size)
        ratio2pivot[self.test_size] = pivot_time
        save_object(ratio2pivot, ratio2pivot_path)
        return pivot_time

    def initialize(self):
        '''
        initialize the model by calculating embeddings per each time step and aligning them all together
        Returns:
            initialized netwrokx graph
        '''

        init_path = join(self.dump_folder, 'init.emb')
        start_time = systime.time()
        if os.path.exists(init_path):
            try:
                graph_nx = nx.read_gpickle(init_path)
            except:
                import pickle5 as pickle
                with open(init_path, 'rb') as input:
                    graph_nx= pickle.load(input)
                    print("loaded using pickle5")



            #self.align=True
        else:
            # initialize embeddings  _initialize_embeddings_siamese


            if(self.model_name=='dgnnsiam'):


                graph_nx = UnsupervisedInductiveGNN._initialize_embeddings_siamese(self, self.pivot_time, self.graph_nx, self.train_time_steps, self.model_name, self.dataset_name)
                print(f"Process finished time taken without alignment in {str(systime.time() - start_time)} seconds")




            else:
                print(f"model {self.model_name} not implemented")
                exit(0)

            nx.write_gpickle(graph_nx, init_path)

        if self.align:

            graph_nx = UnsupervisedInductiveGNN._adjust_node_embeddings(graph_nx, self.train_time_steps)
            print(f"Process finished time taken with alignment in {str(systime.time() - start_time)} seconds")


        return graph_nx



    @staticmethod
    def _initialize_embeddings_siamese(self,pivot_time,graph_nx, times=None,model_name='dgnn',dataset_name="None"):
        '''
        Given a graph, learn embeddings for all nodes in all time step. Attribute 'time' for each edge mast appear
        Args:
            graph_nx: networkx - the given graph
            times: list - of the times we want to work with, if None then calculates for all times in the graph


        Returns:
            graph_nx: networkx - but with attributes for each node for each time step of its embedding
        '''

        timestamps = nx.get_edge_attributes(graph_nx, 'time')
        output_dim_time_encode=32-1
        output_dim=128
        time_list = np.fromiter(timestamps.values(), dtype=float)
        tf.keras.backend.clear_session()
        timeEmbedDict=create_vector_representation(time_list.tolist(), output_dim_time_encode)
        if times is None:
            times = get_graph_times(graph_nx)


        nodeFeatureMap=nx.get_node_attributes(graph_nx,"features") # see this is set in data loader section
        if not nodeFeatureMap:
            print("No node level features found")



        maxTime=np.max(times)
        final_graph_nx_t = get_graph_T(graph_nx, max_time=maxTime)
        final_graph_nx = multigraph2graph(final_graph_nx_t)
        dist_max, dist_argmax = compute_dist_max_and_argmax(final_graph_nx)

        nodes =final_graph_nx.nodes()
        num_nodes=len(nodes)

        A_hat = nx.normalized_laplacian_matrix(final_graph_nx, nodelist=nodes) #sparse
        Adj=nx.adjacency_matrix(final_graph_nx, nodelist=nodes)
        features_withPadding= np.ones((num_nodes,output_dim)) * (1/output_dim)

        if  nodeFeatureMap:
            pivot_time_indx= times.tolist().index(pivot_time) - 1
            features_withTime=np.zeros(shape=[A_hat.shape[0],1])
            for nodeIndx, node in np.ndenumerate(nodes):
                features_withTime[nodeIndx[0]]=np.array(nodeFeatureMap.get(node))[pivot_time_indx]

            features_withPadding = add_lower_to_higher_dynamic(features_withTime, features_withPadding, framework='numpy')





        cpu_to_use=int(os.cpu_count()*0.50)+1
        cpu_to_use=self.num_cpu
        print(f'number of cpu recived: {cpu_to_use}')

        isModelBased=True
        usePretrained=self.is_pretrained
        isTransferLearning=self.is_tranfer_learning



        if isModelBased:
            #pretrained_model_path_relative=f"pretrainedModel_{output_dim}/pretrainedModel.pkl"

            pretrained_model_path = join(os.path.abspath(os.pardir),self.model_path)
            directory = os.path.dirname(pretrained_model_path)

            if not os.path.exists(directory):
                os.makedirs(directory)

            session = tf.compat.v1.Session()


            with session.as_default():


                num_epochs=100
                batch_size=32


                steps_per_ep=int(np.ceil(num_nodes // batch_size))
                if steps_per_ep==0:
                    steps_per_ep=1


                PMI_values=compute_pmi_from_graph_adj(Adj)

                config = tf.compat.v1.ConfigProto()
                config.gpu_options.allow_growth = True
                tf.compat.v1.Session(config=config)
                learning_rate=1e-5
                lr_schedule = tf.keras.optimizers.schedules.ExponentialDecay(
    initial_learning_rate=learning_rate,
    decay_steps=10000,  # Number of steps after which the learning rate decays
    decay_rate=0.9,     # Factor by which the learning rate decays
    staircase=True      # If True, decay in discrete intervals (step-wise)
)


                if isTransferLearning:
                    num_epochs_fine_tune=100
                    X_indices = tf.where(features_withPadding != 0)   # Non-zero indices
                    X_values = tf.gather_nd(features_withPadding, X_indices)   # Random values for non-zero indices
                    X_sparse = tf.SparseTensor(indices=X_indices, values=X_values, dense_shape=(num_nodes, features_withPadding.shape[1]))
                    X_sparse = tf.cast(X_sparse, dtype=tf.float32)
                    A_hat_sparse = scipy_sparse_to_tf_sparse(A_hat, densShape=(num_nodes, num_nodes))
                    Adj_sparse = scipy_sparse_to_tf_sparse(Adj,densShape=(num_nodes, num_nodes))



                    # Define inputs
                    inputs_all = ( X_sparse, A_hat_sparse, Adj_sparse, dist_max, dist_argmax)
                    model = tf.keras.Sequential([DynGraphEmbeddingSiam(inputShape=features_withPadding.shape[1], output_dimension=output_dim)])
                    model(inputs_all)
                    model.load_weights(pretrained_model_path)
                    print("previous weights loaded successfully:")
                    model.trainable = False


                    optim=tf.keras.optimizers.Adam(lr_schedule, beta_1=0.9, beta_2=0.999, epsilon=1e-07, amsgrad=True, name='Adam')
                    tf.keras.optimizers.schedules.ExponentialDecay(initial_learning_rate=0.001, decay_steps=10000, decay_rate=0.9)



                    PMI_values_ind = tf.where(PMI_values > 0)  # Shape: (num_non_zero, 2)
                    PMI_values_tensor = tf.gather_nd(PMI_values, PMI_values_ind)  # Shape: (num_non_zero,)
                    PMI_values_sparse = tf.SparseTensor(
                        indices=PMI_values_ind,
                        values=PMI_values_tensor,
                        dense_shape=(num_nodes, num_nodes)
                    )

                    PMI_values_class_sparse =Adj_sparse

                    PMI_values_sparse = tf.cast(PMI_values_sparse, dtype=tf.float32)
                    PMI_values_class_sparse = tf.cast(PMI_values_class_sparse, dtype=tf.float32)

                    labels = tf.sparse.concat(axis=-1, sp_inputs=[PMI_values_sparse, PMI_values_class_sparse])


                    model.compile(optimizer=optim, loss=pmi_loss_function, metrics=[pmi_loss_function])
                    train_model(model, inputs_all, labels, 1, batch_size)

                    model.trainable = True
                    model.compile(optimizer=optim, loss=pmi_loss_function, metrics=[pmi_loss_function])


                    callback = tf.keras.callbacks.EarlyStopping(monitor='loss', patience=5)

                    visible_devices = tf.config.experimental.list_physical_devices('GPU')
                    gpu_devinces = tf.DeviceSpec(job="localhost", replica=0, device_type="GPU")
                    cpu_devices = tf.DeviceSpec(job="localhost", replica=0, device_type="CPU")
                    if len(visible_devices) > 0:
                        with tf.device(gpu_devinces):
                            train_model(model, inputs_all, labels, num_epochs, batch_size)
                    else:
                        with  tf.device(cpu_devices):

                            train_model(model, inputs_all, labels, num_epochs, batch_size)

                    del inputs_all
                    del labels
                    del PMI_values_tensor




                elif usePretrained:
                    X_indices = tf.where(features_withPadding != 0)   # Non-zero indices
                    X_values = tf.gather_nd(features_withPadding, X_indices)   # Random values for non-zero indices
                    X_sparse = tf.SparseTensor(indices=X_indices, values=X_values, dense_shape=(num_nodes, features_withPadding.shape[1]))
                    X_sparse = tf.cast(X_sparse, dtype=tf.float32)
                    A_hat_sparse = scipy_sparse_to_tf_sparse(A_hat, densShape=(num_nodes, num_nodes))
                    Adj_sparse = scipy_sparse_to_tf_sparse(Adj,densShape=(num_nodes, num_nodes))

                    inputs_all = ( X_sparse, A_hat_sparse, Adj_sparse, dist_max, dist_argmax)
                    model = tf.keras.Sequential([DynGraphEmbeddingSiam(inputShape=features_withPadding.shape[1], output_dimension=output_dim)])

                    model.load_weights(pretrained_model_path)


                else:
                    num_epochs = 500  # Number of training epochs
                    visible_devices = tf.config.experimental.list_physical_devices('GPU')
                    gpu_devinces = tf.DeviceSpec(job="localhost", replica=0, device_type="GPU")
                    cpu_devices = tf.DeviceSpec(job="localhost", replica=0, device_type="CPU")

                    if len(visible_devices) > 0:
                        with tf.device(gpu_devinces):
                            model= create_and_train_model(features_withPadding,Adj,A_hat,PMI_values, dist_max, dist_argmax,num_epochs,output_dim)

                    else:
                        with  tf.device(cpu_devices):

                            model= create_and_train_model(features_withPadding,Adj,A_hat,PMI_values, dist_max, dist_argmax,num_epochs,output_dim)



                    model.save_weights(pretrained_model_path)
                    print(f"model saved successfully at location {pretrained_model_path}")
                    # Load model weights
                listOfEmbeddingAtDifferentTimes=Parallel(n_jobs=cpu_to_use, prefer="threads")(delayed(static_embedding_generation_parallel)(pretrained_model_path,time, get_graph_T(graph_nx, max_time=time), nodeFeatureMap, output_dim, timeEmbedDict.get(time),  times, pivot_time) for time in tqdm(times, desc=f'Generating embedding for time : inductively', unit='time_step'))


            session.close()

        for time,learnedNodeSiameseAndPrevious in tqdm(listOfEmbeddingAtDifferentTimes, desc='Updating static embedding', unit='time_step'):
            nx.set_node_attributes(graph_nx,learnedNodeSiameseAndPrevious,time)


        return graph_nx


    @staticmethod
    def _adjust_node_embeddings(graph, timestamps=None):
        """
        Align embeddings across different time steps in a given graph.

        Args:
            graph: networkx.Graph - The input graph with initialized embeddings.
            timestamps: list - Specific time steps to process; if None, uses all time steps in the graph.

        Returns:
            networkx.Graph - The graph with updated aligned embeddings for each node.
        """
        if timestamps is None:
            timestamps = get_graph_times(graph)

        # Retrieve initial time step embeddings
        initial_node_embeddings = nx.get_node_attributes(graph, timestamps[0])
        prev_embeddings = np.array([initial_node_embeddings[node] for node in initial_node_embeddings])

        # Iterate over subsequent time steps
        for current_time in timestamps[1:]:
            current_node_embeddings = nx.get_node_attributes(graph, current_time)
            curr_embedding_matrix = np.array([current_node_embeddings[node] for node in initial_node_embeddings])

            # Perform orthogonal alignment
            transformation_result = orthogonal(curr_embedding_matrix, prev_embeddings, scale=False, translate=False)
            rotation_matrix = transformation_result.t

            # Apply transformation
            aligned_embeddings = np.dot(curr_embedding_matrix, rotation_matrix)
            aligned_node_embeddings = {node: vec for node, vec in zip(current_node_embeddings, aligned_embeddings)}

            # Update graph attributes
            nx.set_node_attributes(graph, aligned_node_embeddings, current_time)

            # Update previous step embeddings
            prev_embeddings = aligned_embeddings

        return graph

