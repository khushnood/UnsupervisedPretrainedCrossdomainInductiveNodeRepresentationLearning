import tensorflow as tf
from tensorflow.keras.layers import Layer, Dense, Dropout
from scipy.sparse.csgraph import shortest_path
import numpy as np
import networkx as nx

class PGNNLayer(Layer):
    def __init__(self, in_features, out_features):
        super(PGNNLayer, self).__init__()
        self.in_features = in_features
        self.out_features = out_features

        # Weight matrices for message passing
        self.W = self.add_weight(
            shape=(in_features, out_features),
            initializer="glorot_uniform",
            trainable=True,
            name="W"
        )

        # Weight matrix for distance-based message aggregation
        self.W_dist = self.add_weight(
            shape=(out_features, out_features),
            initializer="glorot_uniform",
            trainable=True,
            name="W_dist"
        )

    def call(self, x, dists_max, dists_argmax):
        # Ensure x is a dense tensor
        if isinstance(x, tf.SparseTensor):
            x = tf.sparse.to_dense(x)

        # Perform message passing
        x_transformed = tf.matmul(x, self.W)
        tf.debugging.check_numerics(x_transformed, "x_transformed contains NaN or Inf")

        # Aggregate messages based on distance information
        dists_max = tf.expand_dims(dists_max, -1)  # Shape: (N, K, 1)
        dists_argmax = tf.expand_dims(dists_argmax, -1)  # Shape: (N, K, 1)

        # Validate indices
        tf.debugging.assert_non_negative(dists_argmax)
        tf.debugging.assert_less(dists_argmax, tf.cast(tf.shape(x)[0], dtype=dists_argmax.dtype))

        # Gather the transformed features of the nodes with maximum distances
        x_neighbors = tf.gather(x_transformed, dists_argmax[:, :, 0])  # Shape: (N, K, out_features)

        # Weight the neighbor features by the distance
        weighted_neighbors = x_neighbors * dists_max  # Shape: (N, K, out_features)

        # Sum over the neighbors to get the aggregated message
        aggregated_message = tf.reduce_sum(weighted_neighbors, axis=1)  # Shape: (N, out_features)

        # Combine the transformed features with the aggregated message
        x_position = x_transformed + tf.matmul(aggregated_message, self.W_dist)
        return x_position, x_transformed


class PGNN(tf.keras.Model):
    def __init__(self, input_dim, feature_dim, hidden_dim, output_dim,
                 feature_pre=True, layer_num=2, dropout=True, **kwargs):
        super(PGNN, self).__init__()
        self.feature_pre = feature_pre
        self.layer_num = layer_num
        self.dropout = dropout

        if layer_num == 1:
            hidden_dim = output_dim

        # Feature preprocessing layer
        if feature_pre:
            self.linear_pre = Dense(feature_dim, activation='relu')
            self.conv_first = PGNNLayer(feature_dim, hidden_dim)
        else:
            self.conv_first = PGNNLayer(input_dim, hidden_dim)

        # Hidden layers
        if layer_num > 1:
            self.conv_hidden = [PGNNLayer(hidden_dim, hidden_dim) for _ in range(layer_num - 2)]
            self.conv_out = PGNNLayer(hidden_dim, output_dim)

        # Dropout layer
        if dropout:
            self.dropout_layer = Dropout(rate=0.5)

    def call(self, data, training=False):
        x = data['x']  # Node features (can be sparse)
        dists_max = data['dists_max']  # Maximum distances
        dists_argmax = data['dists_argmax']  # Argument of maximum distances

        # Convert sparse input to dense if necessary
        if isinstance(x, tf.SparseTensor):
            x = tf.sparse.to_dense(x)

        # Feature preprocessing
        if self.feature_pre:
            x = self.linear_pre(x)

        # First PGNN layer
        x_position, x = self.conv_first(x, dists_max, dists_argmax)

        if self.layer_num == 1:
            return x_position

        # Apply dropout if enabled
        if self.dropout:
            x = self.dropout_layer(x, training=training)

        # Hidden layers
        for i in range(self.layer_num - 2):
            _, x = self.conv_hidden[i](x, dists_max, dists_argmax)
            if self.dropout:
                x = self.dropout_layer(x, training=training)

        # Output layer
        x_position, x = self.conv_out(x, dists_max, dists_argmax)

        # Normalize the output
        x_position = tf.math.l2_normalize(x_position, axis=-1)

        return x_position


def compute_dist_max_and_argmax(graph, c=0.5):
    """
    Compute dist_max and dist_argmax for a given NetworkX graph using TensorFlow.

    Args:
        graph (nx.Graph): A NetworkX graph object.
        c (float): Parameter controlling the number of anchorsets.

    Returns:
        dist_max (tf.Tensor): A tensor of shape [num_nodes, num_anchorsets] containing the maximum distance from each node to any node in each anchorset.
        dist_argmax (tf.Tensor): A tensor of shape [num_nodes, num_anchorsets] containing the node index in the anchorset that achieves the maximum distance.
    """
    # Step 1: Compute the shortest path lengths between all pairs of nodes
    num_nodes = graph.number_of_nodes()
    nodes = list(graph.nodes())  # Get the list of nodes in the graph

    # Compute shortest path lengths
    dists_dict = dict(nx.all_pairs_shortest_path_length(graph))

    # Convert shortest path lengths to a distance matrix (inverse of shortest path length)
    dists_array = np.zeros((num_nodes, num_nodes), dtype=np.float32)
    for i in range(num_nodes):
        node_i = nodes[i]  # Get the actual node index
        shortest_dist = dists_dict.get(node_i, {})  # Get the shortest paths for node_i
        for j in range(num_nodes):
            node_j = nodes[j]  # Get the actual node index
            dist = shortest_dist.get(node_j, -1)  # Get the shortest path length
            if dist != -1:
                dists_array[i, j] = 1 / (dist + 1)  # Inverse of shortest path length

    # Convert distance matrix to a TensorFlow tensor
    dists = tf.convert_to_tensor(dists_array, dtype=tf.float32)

    # Step 2: Generate random anchorsets
    def get_random_anchorset(n, c=0.5):
        m = int(np.log2(n))
        copy = int(c * m)
        anchorset_id = []
        for i in range(m):
            anchor_size = int(n / np.exp2(i + 1))
            for j in range(copy):
                anchorset_id.append(np.random.choice(n, size=anchor_size, replace=False))
        return anchorset_id

    anchorset_id = get_random_anchorset(num_nodes, c=c)

    # Step 3: Compute dist_max and dist_argmax
    def get_dist_max(anchorset_id, dist):
        num_nodes = dist.shape[0]
        num_anchorsets = len(anchorset_id)

        # Initialize dist_max and dist_argmax tensors
        dist_max = tf.zeros((num_nodes, num_anchorsets), dtype=tf.float32)
        dist_argmax = tf.zeros((num_nodes, num_anchorsets), dtype=tf.int32)

        for i in range(num_anchorsets):
            temp_id = tf.convert_to_tensor(anchorset_id[i], dtype=tf.int32)
            dist_temp = tf.gather(dist, temp_id, axis=1)  # Shape: [num_nodes, anchor_size]

            # Compute dist_max_temp and dist_argmax_temp
            dist_max_temp = tf.reduce_max(dist_temp, axis=-1)  # Shape: [num_nodes]
            dist_argmax_temp = tf.argmax(dist_temp, axis=-1, output_type=tf.int32)  # Shape: [num_nodes]

            # Gather the node indices from temp_id using dist_argmax_temp
            updates_argmax = tf.gather(temp_id, dist_argmax_temp)  # Shape: [num_nodes]

            # Update dist_max and dist_argmax
            dist_max = tf.tensor_scatter_nd_update(
                dist_max,
                indices=[[j, i] for j in range(num_nodes)],  # Indices for all nodes in the current anchorset
                updates=dist_max_temp  # Updates for all nodes in the current anchorset
            )
            dist_argmax = tf.tensor_scatter_nd_update(
                dist_argmax,
                indices=[[j, i] for j in range(num_nodes)],  # Indices for all nodes in the current anchorset
                updates=updates_argmax  # Updates for all nodes in the current anchorset
            )

        return dist_max, dist_argmax

    dist_max, dist_argmax = get_dist_max(anchorset_id, dists)

    return dist_max, dist_argmax
