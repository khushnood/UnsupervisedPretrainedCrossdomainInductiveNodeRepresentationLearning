import tensorflow as tf
from tensorflow.keras import Sequential
from tensorflow.keras.layers import Dense, ReLU, BatchNormalization, Dropout
from tensorflow.sparse import SparseTensor
from tensorflow.keras.regularizers import l2

class GIN(tf.keras.Model):
    def __init__(self, num_features, out_dimension, num_layers, hidden):
        super(GIN, self).__init__()
        # Initialization Step
        self.initialization = self._build_gin_layer(num_features, hidden)
        # Aggregation Layers
        self.mp_layers = [self._build_gin_layer(hidden, hidden) for _ in range(num_layers - 1)]
        # Classification Head
        self.lin1 = Dense(hidden, activation='relu')
        self.dropout = Dropout(0.5)
        self.lin2 = Dense(out_dimension, activation='relu')

    def _build_gin_layer(self, input_dim, output_dim):
        """Helper function to build a GIN layer."""
        return Sequential([
            Dense(output_dim, activation='relu', kernel_regularizer=l2(0.01)),
            Dense(output_dim, activation='relu', kernel_regularizer=l2(0.01)),
            BatchNormalization()
        ])

    def call(self, inputs, training=False):
        x, edge_index, batch = inputs
        # Convert edge_index to a sparse adjacency matrix
        number_nodes = tf.shape(x)[0]
        adj_matrix = self._edge_index_to_sparse_tensor(edge_index, number_nodes)

        # If x is sparse, convert it to dense for dense layer operations
        if isinstance(x, tf.SparseTensor):
            x = tf.sparse.to_dense(x)

        # Initial GIN layer
        x = self.initialization(x)
        x = self._sparse_message_passing(x, adj_matrix)

        # Aggregation layers
        for layer in self.mp_layers:
            x = layer(x)
            x = self._sparse_message_passing(x, adj_matrix)


        x = self.lin1(x)
        x = self.dropout(x, training=training)
        x = self.lin2(x)

        # Reshape the final output to (x.shape[0], None)
        output_shape = tf.shape(x)
        x = tf.reshape(x, [number_nodes, -1])  # Reshape to (x.shape[0], None)

        return x

    def _edge_index_to_sparse_tensor(self, edge_index, num_nodes):
        """Convert edge_index to a SparseTensor."""
        indices = tf.transpose(edge_index)
        values = tf.ones(tf.shape(edge_index)[1], dtype=tf.float32)
        dense_shape = [num_nodes, num_nodes]
        return SparseTensor(indices=indices, values=values, dense_shape=dense_shape)

    def _sparse_message_passing(self, x, adj_matrix):
        """Perform sparse matrix multiplication for message passing."""
        return tf.sparse.sparse_dense_matmul(adj_matrix, x)
