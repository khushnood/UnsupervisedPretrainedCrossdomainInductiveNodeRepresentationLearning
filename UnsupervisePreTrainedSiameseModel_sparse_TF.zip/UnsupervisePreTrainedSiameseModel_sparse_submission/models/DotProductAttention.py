import tensorflow as tf

class DotProductAttention(tf.keras.layers.Layer):
    def __init__(self, dropout_rate=0.0):
        super(DotProductAttention, self).__init__()
        self.dropout = tf.keras.layers.Dropout(rate=dropout_rate)
        self.softmax = tf.keras.layers.Softmax(axis=-1)

    def call(self, query, key, value, mask=None):
        scores = tf.matmul(query, key, transpose_b=True)  # Calculate attention scores
        if mask is not None:
            scores += (mask * -1e9)  # Apply mask if provided

        attention_weights = self.softmax(scores)  # Apply softmax to get attention weights
        attention_weights = self.dropout(attention_weights)  # Apply dropout

        output = tf.matmul(attention_weights, value)  # Calculate the weighted sum using attention weights

        return output, attention_weights



