class LabelEncoder:
  """
  Assigns unique integer IDs to labels in a consistent manner.
  """
  def __init__(self):
    self.label_to_id = {}
    self.next_id = 0

  def encode(self, label):
    """
    Encodes a label and returns its unique integer ID.

    Args:
      label: The label string to be encoded.

    Returns:
      The unique integer ID assigned to the label.
    """
    if label not in self.label_to_id:
      self.label_to_id[label] = self.next_id
      self.next_id += 1
    return self.label_to_id[label]
