# coding=utf-8
import tensorflow as tf
from .MI_loss import  mutual_information_loss

def add_self_loop_edge(edge_index, num_nodes, edge_weight=None, fill_weight=1.0):
    diagnal_edge_index = tf.stack([tf.range(num_nodes, dtype=tf.int32)] * 2, axis=0)
    updated_edge_index = tf.concat([edge_index, diagnal_edge_index], axis=1)

    if not tf.is_tensor(edge_index):
        updated_edge_index = updated_edge_index.numpy()

    if edge_weight is not None:
        diagnal_edge_weight = tf.cast(tf.fill([num_nodes], fill_weight), tf.float32)
        updated_edge_weight = tf.concat([edge_weight, diagnal_edge_weight], axis=0)

        if not tf.is_tensor(edge_weight):
            updated_edge_weight = updated_edge_weight.numpy()
    else:
        updated_edge_weight = None

    return updated_edge_index, updated_edge_weight
# Dummy PMI loss function
def pmi_loss_function(labels, y_pred, alpha=100.0, beta=100.0, margin=1.0,type="CONL"):
    """
    Combined PMI-based and contrastive loss for Siamese GNNs.

    Args:
        labels: SparseTensor of shape (batch_size, num_nodes, num_nodes, 2), containing ground truth PMI values and binary labels.
        y_pred: Tensor of shape (batch_size, num_nodes, 2 * embedding_dim), containing predicted node embeddings.
        alpha: Weight for PMI-based loss.
        beta: Weight for contrastive loss.
        margin: Margin for the contrastive loss (default: 1.0).
        type: PMIL: PMI based only
              CONL: For Contranstive Loss
              MIL: For Mutual information based Loss
              COMBL: PMIL + CONL

    Returns:
        loss: Scalar Tensor representing the combined loss.
    """
    # Split the predicted embeddings
    learned_node_features_from, learned_node_features_to = tf.split(y_pred, num_or_size_splits=2, axis=-1)


    # Convert sparse labels to dense if necessary
    if isinstance(labels, tf.SparseTensor):
        labels_dense = tf.sparse.to_dense(labels)
    else:
        labels_dense = labels

    # Split the labels into ground truth PMI values and binary labels
    y_true, y_true_class = tf.split(labels_dense, num_or_size_splits=2, axis=-1)



    # Compute the prediction score (dot product between embeddings)
    prediction_score = tf.matmul(learned_node_features_from, learned_node_features_to, transpose_b=True)

    # For undirected graphs, the prediction score is already symmetric
    # No need to add it to its transpose
    # prediction_score = (tf.add(prediction_score, tf.transpose(prediction_score))) / 2.0  # Remove this line

    epsilon = 1e-7  # Small epsilon to avoid NaN

    # Compute the KL divergence loss
    lossKL = tf.keras.losses.kullback_leibler_divergence(y_true, prediction_score)

    # Mask for positive and negative labels
    mask_label_1 = tf.cast(tf.greater(y_true, 0.0), dtype=tf.float32)  # Positive pairs
    mask_label_0 = 1 - mask_label_1  # Negative pairs

    # Weighted energy terms
    eng_pos = lossKL * mask_label_1
    eng_neg = lossKL * mask_label_0

    # Improved energy term
    energy = tf.square(eng_pos) + tf.exp(-eng_neg)

    # PMI-based loss
    pmiLoss = energy
    if type=="PMIL":
        return tf.reduce_mean(pmiLoss)


    # Contrastive Loss
    squared_diff = tf.square(learned_node_features_from - learned_node_features_to)
    # Compute the Euclidean distance with numerical stability
    distance = tf.sqrt(tf.reduce_sum(squared_diff, axis=1) + epsilon)
    # Compute the contrastive loss
    contrastive_loss = y_true_class * tf.square(distance) + (1 - y_true_class) * tf.square(tf.maximum(0.0, margin - distance))
    if type=="CONL":
        return tf.reduce_mean(contrastive_loss)


    # Combine the losses with explicit weighting
    #combined_loss = alpha * tf.reduce_mean(pmiLoss) + beta * tf.reduce_mean(contrastive_loss)

    #combined_loss=mutual_information_loss(learned_node_features_from,learned_node_features_to,y_true_class)
    combined_loss=tf.reduce_mean(contrastive_loss)


    return combined_loss

def pmi_loss_function_sparse_with_regul(labels, y_pred, model_weights, alpha=100.0, beta=100.0, margin=1.0, l2_lambda=0.01):
    """
    Combined PMI-based and contrastive loss for Siamese GNNs.

    Args:
        labels: SparseTensor of shape (batch_size, num_nodes, num_nodes, 2), containing ground truth PMI values and binary labels.
        y_pred: Tensor of shape (batch_size, num_nodes, 2 * embedding_dim), containing predicted node embeddings.
        alpha: Weight for PMI-based loss.
        beta: Weight for contrastive loss.
        margin: Margin for the contrastive loss (default: 1.0).

    Returns:
        loss: Scalar Tensor representing the combined loss.
    """
    # Split the predicted embeddings
    learned_node_features_from, learned_node_features_to = tf.split(y_pred, num_or_size_splits=2, axis=-1)

    # Convert sparse labels to dense if necessary
    if isinstance(labels, tf.SparseTensor):
        labels_dense = tf.sparse.to_dense(labels)
    else:
        labels_dense = labels

    # Split the labels into ground truth PMI values and binary labels
    y_true, y_true_class = tf.split(labels_dense, num_or_size_splits=2, axis=-1)


    # Compute the prediction score (dot product between embeddings)
    prediction_score = tf.matmul(learned_node_features_from, learned_node_features_to, transpose_b=True)

    # For undirected graphs, the prediction score is already symmetric
    # No need to add it to its transpose
    # prediction_score = (tf.add(prediction_score, tf.transpose(prediction_score))) / 2.0  # Remove this line

    epsilon = 1e-7  # Small epsilon to avoid NaN

    # Compute the KL divergence loss
    lossKL = tf.keras.losses.kullback_leibler_divergence(y_true, prediction_score)

    # Mask for positive and negative labels
    mask_label_1 = tf.cast(tf.greater(y_true, 0.0), dtype=tf.float32)  # Positive pairs
    mask_label_0 = 1 - mask_label_1  # Negative pairs

    # Weighted energy terms
    eng_pos = lossKL * mask_label_1
    eng_neg = lossKL * mask_label_0

    # Improved energy term
    energy = tf.square(eng_pos) + tf.exp(-eng_neg)

    # PMI-based loss
    pmiLoss = energy

    # Contrastive Loss
    squared_diff = tf.square(learned_node_features_from - learned_node_features_to)

    # Compute the Euclidean distance with numerical stability
    distance = tf.sqrt(tf.reduce_sum(squared_diff, axis=1) + epsilon)

    # Compute the contrastive loss
    contrastive_loss = y_true_class * tf.square(distance) + (1 - y_true_class) * tf.square(tf.maximum(0.0, margin - distance))

    # Combine the losses with explicit weighting
    combined_loss = alpha * tf.reduce_mean(pmiLoss) + beta * tf.reduce_mean(contrastive_loss)

    # Add L2 regularization
    l2_regularization = tf.add_n([tf.nn.l2_loss(w) for w in model_weights])  # L2 norm of all weights
    combined_loss += l2_lambda * l2_regularization  # Add regularization term to the loss

    return combined_loss
