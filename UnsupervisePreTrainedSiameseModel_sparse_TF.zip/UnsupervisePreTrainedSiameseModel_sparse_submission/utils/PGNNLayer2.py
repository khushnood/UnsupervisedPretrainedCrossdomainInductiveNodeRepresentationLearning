import tensorflow as tf
from tensorflow.keras.layers import Layer, Dense, Dropout
from tensorflow.keras import Sequential
from scipy.sparse.csgraph import shortest_path

class PGNNLayer(Layer):
    def __init__(self, in_features, out_features):
        super(PGNNLayer, self).__init__()
        self.in_features = in_features
        self.out_features = out_features

        # Weight matrices for message passing
        self.W = self.add_weight(
            shape=(in_features, out_features),
            initializer="glorot_uniform",
            trainable=True,
            name="W"
        )

    def call(self, x, dists_max, dists_argmax):
        """
        Forward pass for the PGNN layer.
        """
        # Ensure x is a dense tensor
        if isinstance(x, tf.SparseTensor):
            x = tf.sparse.to_dense(x)

        # Perform message passing (dummy implementation for now)
        x_position = tf.matmul(x, self.W)  # Shape: (N, out_features)
        x = tf.matmul(x, self.W)  # Shape: (N, out_features)
        return x_position, x


class PGNN(tf.keras.Model):
    def __init__(self, input_dim, feature_dim, hidden_dim, output_dim,
                 feature_pre=True, layer_num=2, dropout=True, **kwargs):
        super(PGNN, self).__init__()
        self.feature_pre = feature_pre
        self.layer_num = layer_num
        self.dropout = dropout

        if layer_num == 1:
            hidden_dim = output_dim

        # Feature preprocessing layer
        if feature_pre:
            self.linear_pre = Dense(feature_dim, activation=None)
            self.conv_first = PGNNLayer(feature_dim, hidden_dim)
        else:
            self.conv_first = PGNNLayer(input_dim, hidden_dim)

        # Hidden layers
        if layer_num > 1:
            self.conv_hidden = [PGNNLayer(hidden_dim, hidden_dim) for _ in range(layer_num - 2)]
            self.conv_out = PGNNLayer(hidden_dim, output_dim)

        # Dropout layer
        if dropout:
            self.dropout_layer = Dropout(rate=0.5)

    def call(self, data, training=False):
        x = data['x']  # Node features (can be sparse)
        dists_max = data['dists_max']  # Maximum distances
        dists_argmax = data['dists_argmax']  # Argument of maximum distances

        # Convert sparse input to dense if necessary
        if isinstance(x, tf.SparseTensor):
            x = tf.sparse.to_dense(x)

        # Feature preprocessing
        if self.feature_pre:
            x = self.linear_pre(x)

        # First PGNN layer
        x_position, x = self.conv_first(x, dists_max, dists_argmax)

        if self.layer_num == 1:
            return x_position

        # Optional: Apply ReLU activation
        # x = tf.nn.relu(x)

        # Apply dropout if enabled
        if self.dropout:
            x = self.dropout_layer(x, training=training)

        # Hidden layers
        for i in range(self.layer_num - 2):
            _, x = self.conv_hidden[i](x, dists_max, dists_argmax)
            # Optional: Apply ReLU activation
            # x = tf.nn.relu(x)
            if self.dropout:
                x = self.dropout_layer(x, training=training)

        # Output layer
        x_position, x = self.conv_out(x, dists_max, dists_argmax)

        # Normalize the output
        x_position = tf.math.l2_normalize(x_position, axis=-1)

        return x_position

if __name__ == '__main__':
    import numpy as np
    import tensorflow as tf
    from scipy.sparse.csgraph import shortest_path

    # Example inputs
    input_dim = 32
    feature_dim = 64
    hidden_dim = 128
    output_dim = 16
    layer_num = 2
    dropout = True

    # Initialize the model
    model = PGNN(input_dim, feature_dim, hidden_dim, output_dim, feature_pre=True, layer_num=layer_num, dropout=dropout)

    # Example sparse data
    indices = [[0, 1], [1, 2], [2, 3]]  # Non-zero indices
    values = [1.0, 2.0, 3.0]  # Non-zero values
    dense_shape = [100, input_dim]  # Shape of the sparse tensor
    x = tf.SparseTensor(indices=indices, values=values, dense_shape=dense_shape)

    # Example adjacency Laplacian
    adjacency_laplacian = np.array([[0, 1, 0, 0],
                                    [1, 0, 2, 0],
                                    [0, 2, 0, 3],
                                    [0, 0, 3, 0]])

    # Compute pairwise distances using shortest path algorithm
    dist_matrix = shortest_path(adjacency_laplacian, directed=False)

    # Compute dist_max and dist_argmax
    dist_max = np.max(dist_matrix, axis=1)  # Maximum distance from each node
    dist_argmax = np.argmax(dist_matrix, axis=1)  # Node index that achieves the maximum distance

    # Convert to TensorFlow tensors
    dist_max = tf.convert_to_tensor(dist_max, dtype=tf.float32)
    dist_argmax = tf.convert_to_tensor(dist_argmax, dtype=tf.float32)

    # Expand dimensions to match the expected input shape [100, 100]
    dist_max = tf.expand_dims(dist_max, axis=1)
    dist_argmax = tf.expand_dims(dist_argmax, axis=1)

    # Example data
    data = {
        'x': x,  # Sparse node features (100 nodes, 32 features)
        'dists_max': dist_max,  # Maximum distances (100 nodes)
        'dists_argmax': dist_argmax  # Argument of maximum distances (100 nodes)
    }

    # Pass data through the model
    output = model(data, training=True)
    print("Output shape:", output.shape)

