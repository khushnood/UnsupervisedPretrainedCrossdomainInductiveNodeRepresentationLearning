import tensorflow as tf

def create_vector_representation(time_list, output_dim):
    max_time = int(max(time_list))
    min_time = int(min(time_list))
    time_range = max_time - min_time + 1
    # Calculate inter-event times
    inter_event_times = [time_list[i + 1] - time_list[i] for i in range(len(time_list) - 1)]
    inter_event_times.append(0)  # For the last event, there's no subsequent event
    # Initialize a random weight matrix for feature hashing
    random_weights = tf.Variable(
        tf.random.normal(shape=(time_range, output_dim), dtype=tf.float32),
        name="random_weights"
    )
    # Convert input lists to tensors
    input_times = tf.constant(time_list, dtype=tf.float32)
    input_inter_event_times = tf.constant(inter_event_times, dtype=tf.float32)

    # Map input times to their respective indices in the feature hashing matrix
    time_indices = tf.cast(input_times - min_time, dtype=tf.int32)
    time_vectors = tf.nn.embedding_lookup(random_weights, time_indices)

    # Use inter-event times directly as part of the vector representation
    inter_event_vectors = tf.expand_dims(input_inter_event_times, axis=1)

    # Concatenate time and inter-event vectors
    combined_vectors = tf.concat([time_vectors, inter_event_vectors], axis=1)



    vectors_with_inter_event_times = combined_vectors.numpy()


    time_vector_dict = {time_list[i]: vectors_with_inter_event_times[i] for i in range(len(time_list))}

    return time_vector_dict
