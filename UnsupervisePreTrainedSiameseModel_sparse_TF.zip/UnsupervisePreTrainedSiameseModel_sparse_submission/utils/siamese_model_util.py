import tensorflow as tf
import numpy as np
from models.DynGraphEmbeddingSiam_sparse import DynGraphEmbeddingSiam
import time as systime
from utils.graph_utils import get_graph_T, get_pivot_time, get_graph_times, multigraph2graph
import gc
import networkx as nx
from utils.GNN_util_tf import pmi_loss_function,pmi_loss_function_sparse_with_regul


def contrastive_loss(y_true, learned_node_features_from, learned_node_features_to, margin=1.0):
    """
    Contrastive loss function for Siamese GNNs.

    Args:
        y_true: Tensor of shape (batch_size,), containing binary labels (1 for similar pairs, 0 for dissimilar pairs).
        learned_node_features_from: Tensor of shape (batch_size, embedding_dim), containing embeddings of the first graph/node.
        learned_node_features_to: Tensor of shape (batch_size, embedding_dim), containing embeddings of the second graph/node.
        margin: Margin for the contrastive loss (default: 1.0).

    Returns:
        loss: Scalar Tensor representing the contrastive loss.
    """
    # Compute the squared difference between the embeddings
    squared_diff = tf.square(learned_node_features_from - learned_node_features_to)

    # Compute the Euclidean distance with numerical stability
    epsilon = 1e-7  # Small epsilon to avoid NaN
    distance = tf.sqrt(tf.reduce_sum(squared_diff, axis=1) + epsilon)

    # Compute the contrastive loss
    loss = y_true * tf.square(distance) + (1 - y_true) * tf.square(tf.maximum(0.0, margin - distance))

    # Average the loss over the batch
    loss = tf.reduce_mean(loss)

    return loss








def pmi_loss_function_sparse(labels, y_pred, alpha=100.0, beta=100.0, margin=1.0):
    """
    Combined PMI-based and contrastive loss for Siamese GNNs.

    Args:
        labels: SparseTensor of shape (batch_size, num_nodes, num_nodes, 2), containing ground truth PMI values and binary labels.
        y_pred: SparseTensor of shape (batch_size, num_nodes, 2 * embedding_dim), containing predicted node embeddings.
        alpha: Weight for PMI-based loss.
        beta: Weight for contrastive loss.
        margin: Margin for the contrastive loss (default: 1.0).

    Returns:
        loss: Scalar Tensor representing the combined loss.
    """
    # Split the predicted embeddings
    #learned_node_features_from, learned_node_features_to = tf.sparse.split(y_pred, num_split=2, axis=-1)
    learned_node_features_from = tf.sparse.slice(y_pred, start=[0, 0], size=[tf.shape(y_pred)[0], tf.shape(y_pred)[1] // 2])
    learned_node_features_to = tf.sparse.slice(y_pred, start=[0, tf.shape(y_pred)[1] // 2], size=[tf.shape(y_pred)[0], tf.shape(y_pred)[1] // 2])

    # Split the labels into ground truth PMI values and binary labels

    y_true = tf.sparse.slice(labels, start=[0, 0], size=[tf.shape(labels)[0], tf.shape(labels)[1] // 2])
    y_true_class = tf.sparse.slice(labels, start=[0, tf.shape(labels)[1] // 2], size=[tf.shape(labels)[0], tf.shape(labels)[1] // 2])

    # Convert sparse tensors to dense for operations that require dense tensors
    y_true_dense = tf.sparse.to_dense(y_true)
    y_true_class_dense = tf.sparse.to_dense(y_true_class)

    # Ensure consistent data types (e.g., float32)
    y_true_dense = tf.cast(y_true_dense, dtype=tf.float32)
    y_true_class_dense = tf.cast(y_true_class_dense, dtype=tf.float32)
    learned_node_features_from = tf.cast(learned_node_features_from.values, dtype=tf.float32)
    learned_node_features_to = tf.cast(learned_node_features_to.values, dtype=tf.float32)
    margin = tf.cast(margin, dtype=tf.float32)

    # Compute the prediction score (dot product between embeddings)
    prediction_score = tf.matmul(learned_node_features_from, learned_node_features_to, transpose_b=True)

    epsilon = 1e-7  # Small epsilon to avoid NaN

    # Compute the KL divergence loss
    lossKL = tf.keras.losses.kullback_leibler_divergence(y_true_dense, prediction_score)

    # Mask for positive and negative labels
    mask_label_1 = tf.cast(tf.greater(y_true_dense, 0.0), dtype=tf.float32)  # Positive pairs
    mask_label_0 = 1 - mask_label_1  # Negative pairs

    # Weighted energy terms
    eng_pos = lossKL * mask_label_1
    eng_neg = lossKL * mask_label_0

    # Improved energy term
    energy = tf.square(eng_pos) + tf.exp(-eng_neg)

    # PMI-based loss
    pmiLoss = energy

    # Contrastive Loss
    squared_diff = tf.square(learned_node_features_from - learned_node_features_to)

    # Compute the Euclidean distance with numerical stability
    distance = tf.sqrt(tf.reduce_sum(squared_diff, axis=1) + epsilon)

    # Compute the contrastive loss
    contrastive_loss = y_true_class_dense * tf.square(distance) + (1 - y_true_class_dense) * tf.square(tf.maximum(0.0, margin - distance))

    # Combine the losses with explicit weighting
    combined_loss = alpha * tf.reduce_mean(pmiLoss) + beta * tf.reduce_mean(contrastive_loss)

    return combined_loss


def energy_kl(self, pairs):
    """
    Computes the energy of a set of node pairs as the KL divergence between their respective Gaussian embeddings.
    Parameters
    ----------
    pairs : array-like, shape [?, 2]
        The edges/non-edges for which the energy is calculated
    Returns
    -------
    energy : array-like, shape [?]
        The energy of each pair given the currently learned model
    """
    ij_mu = tf.gather(self.mu, pairs)
    ij_sigma = tf.gather(self.sigma, pairs)
    sigma_ratio = ij_sigma[:, 1] / ij_sigma[:, 0]
    trace_fac = tf.reduce_sum(sigma_ratio, 1)
    log_det = tf.reduce_sum(tf.log(sigma_ratio + 1e-14), 1)
    mu_diff_sq = tf.reduce_sum(tf.square(ij_mu[:, 0] - ij_mu[:, 1]) / ij_sigma[:, 0], 1)
    return 0.5 * (trace_fac + mu_diff_sq - self.L - log_det)


import scipy.sparse as sp

def compute_pmi_from_graph_adj_old(adjacency_matrix):
    if sp.issparse(adjacency_matrix):
        adjacency_matrix = adjacency_matrix.toarray()
    total_sum = np.sum(adjacency_matrix)
    row_sum = np.sum(adjacency_matrix, axis=1)
    col_sum = np.sum(adjacency_matrix, axis=0)
    total_number_of_edges = np.count_nonzero(adjacency_matrix)

    pmi_values_adjac = np.zeros((adjacency_matrix.shape))

    for i in range(adjacency_matrix.shape[0]):
        for j in range(adjacency_matrix.shape[1]):
            if adjacency_matrix[i, j] != 0:
                pmi = np.log2((adjacency_matrix[i, j] * total_sum) / (row_sum[i] * col_sum[j]))
                pmi_values_adjac[i, j] = max(0, pmi)
                pmi_values_adjac[j, i] = max(0, pmi)

    return pmi_values_adjac


def compute_pmi_from_graph_adj(adjacency_matrix):
    """
    Compute PMI (Pointwise Mutual Information) values from a given adjacency matrix.

    Args:
        adjacency_matrix: A scipy sparse matrix or numpy array representing the adjacency matrix.

    Returns:
        A numpy array containing the PMI values.
    """
    # Convert the adjacency matrix to a dense numpy array if it's sparse
    if sp.issparse(adjacency_matrix):
        adjacency_matrix = adjacency_matrix.toarray()

    # Compute total sum, row sums, and column sums
    total_sum = np.sum(adjacency_matrix)
    row_sum = np.sum(adjacency_matrix, axis=1, keepdims=True)  # Shape: [num_nodes, 1]
    col_sum = np.sum(adjacency_matrix, axis=0, keepdims=True)  # Shape: [1, num_nodes]

    # Avoid division by zero by adding a small epsilon
    epsilon = 1e-10
    row_sum[row_sum == 0] = epsilon
    col_sum[col_sum == 0] = epsilon

    # Compute PMI values using vectorized operations
    pmi_values = np.log2((adjacency_matrix * total_sum) / (row_sum * col_sum) + epsilon)

    # Set negative PMI values to 0
    pmi_values[pmi_values < 0] = 0

    # Ensure symmetry (since PMI is symmetric for undirected graphs)
    pmi_values = np.maximum(pmi_values, pmi_values.T)

    return pmi_values

def compute_PMI_edge(graph, in_degrees, out_degrees,shape):
    size=graph[0].shape[0]
    PMI_values = np.zeros((shape))

    for ind, head, tail in zip(range(size),*graph):
        pmi = (size) / (out_degrees[head] * in_degrees[tail])
        PMI_values[head, tail] = np.log(pmi) if pmi > 0 else 0
    return PMI_values
def compute_PMI_edge_old(graph, in_degrees, out_degrees):
    size=graph[0].shape[0]
    PMI_values = np.zeros((size, 1))

    for ind, head, tail in zip(range(size),*graph):
        pmi = (size) / (out_degrees[head] * in_degrees[tail])
        PMI_values[ind, 0] = np.log(pmi) if pmi > 0 else 0
    return PMI_values


import tensorflow as tf
import numpy as np
import networkx as nx
import time as systime
import gc


def scipy_sparse_to_tf_sparse(A_hat_tensor, densShape):
    # Convert the sparse matrix to COO format
    coo = A_hat_tensor.tocoo()

    # Extract indices and values
    indices = np.column_stack((coo.row, coo.col))
    values = coo.data

    # Convert indices to int64
    indices = indices.astype(np.int64)
    values = tf.cast(values, dtype=tf.float32)

    # Create the SparseTensor
    tf_sparse = tf.SparseTensor(indices=indices, values=values, dense_shape=densShape)

    return tf_sparse
def static_embedding_generation_parallel(trained_model_path, time, cur_graph_nx_1, nodeFeatureMap, output_dim, timeEmbeddings_time, uniqueTimeArray, pivot_time):
    start_time = systime.time()
    print(f"Process started for time: {time}")

    # Convert multigraph to graph
    cur_graph_nx = multigraph2graph(cur_graph_nx_1)
    nodes = cur_graph_nx.nodes()
    num_nodes=len(nodes)


    # Compute normalized Laplacian and adjacency matrices
    A_hat = nx.normalized_laplacian_matrix(cur_graph_nx, nodelist=nodes)
    Adj = nx.adjacency_matrix(cur_graph_nx, nodelist=nodes)
    dist_max, dist_argmax = compute_dist_max_and_argmax(cur_graph_nx)

    # Initialize features with padding
    features_withPadding = np.ones((num_nodes, output_dim)) * (1 / output_dim)

    # Add node features if nodeFeatureMap is provided
    if nodeFeatureMap:
        pivot_time_indx = uniqueTimeArray.tolist().index(pivot_time) - 1  # Adjust for time-based features
        features_withTime = np.zeros(shape=[num_nodes, 1])
        for nodeIndx, node in np.ndenumerate(nodes):
            features_withTime[nodeIndx[0]] = np.array(nodeFeatureMap.get(node))[pivot_time_indx]
        features_withPadding = add_lower_to_higher_dynamic(features_withTime, features_withPadding, framework='numpy')

    # Model-based embedding generation
    isModelBased = True

    if isModelBased:
        # Concatenate inputs
        X_indices = tf.where(features_withPadding != 0)   # Non-zero indices
        X_values = tf.gather_nd(features_withPadding, X_indices)   # Random values for non-zero indices
        X_sparse = tf.SparseTensor(indices=X_indices, values=X_values, dense_shape=(num_nodes, features_withPadding.shape[1]))
        X_sparse = tf.cast(X_sparse, dtype=tf.float32)
        A_hat_sparse = scipy_sparse_to_tf_sparse(A_hat, densShape=(num_nodes, num_nodes))
        Adj_sparse = scipy_sparse_to_tf_sparse(Adj,densShape=(num_nodes, num_nodes))
        inputs_all = ( X_sparse, A_hat_sparse, Adj_sparse, dist_max, dist_argmax)


        # Load the trained model
        trained_model = tf.keras.Sequential([DynGraphEmbeddingSiam(inputShape=features_withPadding.shape[1], output_dimension=output_dim)])

        trained_model(inputs_all, training=False)

        trained_model.load_weights(trained_model_path)
        visible_devices = tf.config.list_physical_devices('GPU')
        if visible_devices:
            device = "/GPU:0"
        else:
            device = "/CPU:0"

        # Run inference on the appropriate device
        with tf.device(device):
            #inputs_tensor = tf.convert_to_tensor(inputs_all, dtype=tf.float32)
            output = trained_model(inputs_all, training=False)

        # Split the output
        embeddings, learned_node_features_to = np.split(output.numpy(), 2, axis=-1)

        # Combine embeddings with time and node features
        if nodeFeatureMap:
            learnedNodeSiameseAndPrevious = {
                node: np.concatenate([embeddings[nodeIndx[0], :].flat, timeEmbeddings_time.reshape([-1]), features_withTime[nodeIndx[0]].flat])
                for nodeIndx, node in np.ndenumerate(nodes)
            }
        else:
            learnedNodeSiameseAndPrevious = {
                node: np.concatenate([embeddings[nodeIndx[0], :].flat, timeEmbeddings_time.reshape([-1])])
                for nodeIndx, node in np.ndenumerate(nodes)
            }

        # Clean up
        del inputs_all
        del learned_node_features_to
        del trained_model
        gc.collect()

    print(f"Process finished for time: {time} in {str(systime.time() - start_time)} seconds")

    return time, learnedNodeSiameseAndPrevious
def generate_batch_data(features, Adj, A_hat, PMI_values, batch_size=32):
    n = features.shape[0]

    # Randomly sample nodes to form a batch
    indices = np.random.choice(n, size=batch_size, replace=False)

    # Construct input data
    feature_batch = features[indices]
    adj_batch = Adj[indices]
    a_hat_batch = A_hat[indices]
    input_batch = np.concatenate([feature_batch, adj_batch, a_hat_batch], axis=1)

    # Use PMI_values as labels
    labels_batch = PMI_values[indices]

    return input_batch, labels_batch

def time_order_prediction_loss(embeddings, PMIS):
        """
        Loss function for time order prediction using embeddings.

        Args:
            embeddings: A tensor of shape (batch_size, seq_len, embedding_dim)
                representing the time embeddings.

        Returns:
            A scalar tensor representing the loss value.
        """

        # Reshape embeddings to (batch_size * seq_len, embedding_dim)
        flattened_embeddings = tf.reshape(embeddings, (-1, embeddings.shape[-1]))

        # Create a dense layer for prediction
        prediction_layer = tf.keras.layers.Dense(1, activation='sigmoid')

        # Predict the probability of each embedding being later in time
        predictions = prediction_layer(flattened_embeddings)

        # Generate target labels for time order
        #target_labels = tf.constant(lables, dtype=tf.float32)  # 0, 1, 2, ..., seq_len-1
        #target_labels = tf.tile(target_labels, [embeddings.shape[0]])  # Repeat for each batch
        #target_labels = tf.reshape(target_labels, (-1, 1))  # Reshape to match predictions

        # Calculate loss using binary crossentropy
        loss = tf.keras.losses.mean_squared_error(PMIS, predictions)

        return tf.reduce_mean(loss)

def compute_pmi_from_graphAdj(adjacency_matrix):
    total_sum = np.sum(adjacency_matrix)
    row_sum = np.sum(adjacency_matrix, axis=1)
    col_sum = np.sum(adjacency_matrix, axis=0)
    totalNumberOfEdges = np.count_nonzero(adjacency_matrix)

    pmi_values_adjac = np.zeros((adjacency_matrix.shape))
    #count = 0

    for i in range(adjacency_matrix.shape[0]):
        for j in range(adjacency_matrix.shape[1]):
            if adjacency_matrix[i, j] != 0:
                pmi = np.log2((adjacency_matrix[i, j] * total_sum) / (row_sum[i] * col_sum[j]))
                pmi_values_adjac[i, j] = max(0, pmi)  # Apply a non-negativity constraint
                #count += 1

    return pmi_values_adjac

def add_lower_to_higher_dynamic(lower, higher, framework='numpy'):
    """
    Adds elements of a smaller matrix (lower-dimensional) into a larger matrix (higher-dimensional).
    Handles cases where one dimension of the larger matrix is greater.

    Parameters:
        lower (array-like): The smaller matrix of size (m, k).
        higher (array-like): The larger matrix of size (m, k + l).
        framework (str): Either 'numpy' or 'tensorflow' to specify the backend.

    Returns:
        array-like: The updated larger matrix.
    """
    if framework == 'numpy':
        lower = np.array(lower)
        higher = np.array(higher)

        # Extract dimensions
        m1, k1 = lower.shape
        m2, k2 = higher.shape

        if m1 != m2 or k1 > k2:
            raise ValueError("Lower matrix must have matching rows and columns less than or equal to the higher matrix.")

        # Create a padded version of the lower matrix to match the higher matrix

        higher[:, :k1] = lower

        # replace the init value to actual features. padded lower matrix to the higher matrix
        return higher

    elif framework == 'tensorflow':
        lower = tf.convert_to_tensor(lower, dtype=tf.float64)
        higher = tf.convert_to_tensor(higher, dtype=tf.float64)

        # Extract dimensions
        lower_shape = tf.shape(lower)
        higher_shape = tf.shape(higher)

        if lower_shape[0] != higher_shape[0] or lower_shape[1] > higher_shape[1]:
            raise ValueError("Lower matrix must have matching rows and columns less than or equal to the higher matrix.")

        # Create a padded version of the lower matrix
        paddings = [[0, 0], [0, higher_shape[1] - lower_shape[1]]]
        padded_lower = tf.pad(lower, paddings)

        # Add the padded lower matrix to the higher matrix
        return higher + padded_lower

    else:
        raise ValueError("Framework must be either 'numpy' or 'tensorflow'.")

def train_model(model, inputs_all, labels, num_epochs, batch_size,savePath=None):
    # Disable eager execution for TensorFlow 2.x compatibility
    tf.compat.v1.disable_v2_behavior()

    # Create a TensorFlow session
    with tf.compat.v1.Session() as sess:
        sess.run(tf.compat.v1.global_variables_initializer())

        # Evaluate labels to a NumPy array
        labels_np = labels.eval(session=sess)

        for epoch in range(num_epochs):
            # Get a batch of data
            batch_inputs, batch_labels = inputs_all, labels_np
            #batch_inputs, batch_labels = get_batch(inputs_all, labels, batch_size, sess)

            # Create feed dictionary
            feed_dict = {
                model.inputs_all: batch_inputs,
                model.labels: batch_labels  # Use the NumPy array here
            }

            # Run the session
            loss, _ = sess.run([model.loss, model.optimizer], feed_dict=feed_dict)
            print(f"Epoch {epoch + 1}, Loss: {loss}")

        model.save_weights(sess,path=savePath)
        print(f"model saved successfully at location: {savePath}")

# Test case
def get_batch(data, labels, batch_size, session):
    """
    Get a batch of data from dense inputs.
    """
    num_samples = data.shape[0]
    indices = np.random.choice(num_samples, batch_size, replace=False)

    # Convert NumPy array indices to TensorFlow tensor
    indices_tf = tf.convert_to_tensor(indices, dtype=tf.int32)

    # Gather the corresponding data and labels
    batch_data = tf.gather(data, indices_tf)
    batch_labels = tf.gather(labels, indices_tf)

    # Evaluate the tensors to get NumPy arrays
    batch_data_np = batch_data.eval(session=session)
    batch_labels_np = batch_labels.eval(session=session)

    return batch_data_np, batch_labels_np




def pmi_loss_function_placeholder(labels, y_pred, alpha=100.0, beta=100.0, margin=1.0):
    """
    Combined PMI-based and contrastive loss for Siamese GNNs.

    Args:
        labels: Tensor of shape (batch_size, num_nodes, num_nodes, 2), containing ground truth PMI values and binary labels.
        y_pred: Tensor of shape (batch_size, num_nodes, 2 * embedding_dim), containing predicted node embeddings.
        alpha: Weight for PMI-based loss.
        beta: Weight for contrastive loss.
        margin: Margin for the contrastive loss (default: 1.0).

    Returns:
        loss: Scalar Tensor representing the combined loss.
    """
    # Split the predicted embeddings
    learned_node_features_from, learned_node_features_to = tf.split(y_pred, num_or_size_splits=2, axis=-1)

    # Split the labels into ground truth PMI values and binary labels
    y_true, y_true_class = tf.split(labels, num_or_size_splits=2, axis=-1)

    # Compute the prediction score (dot product between embeddings)
    prediction_score = tf.matmul(learned_node_features_from, learned_node_features_to, transpose_b=True)

    epsilon = 1e-7  # Small epsilon to avoid NaN

    # Compute the KL divergence loss
    lossKL = tf.keras.losses.kullback_leibler_divergence(y_true, prediction_score)

    # Mask for positive and negative labels
    mask_label_1 = tf.cast(tf.greater(y_true, 0.0), dtype=tf.float64)  # Positive pairs
    mask_label_0 = 1 - mask_label_1  # Negative pairs

    # Weighted energy terms
    eng_pos = lossKL * mask_label_1
    eng_neg = lossKL * mask_label_0

    # Improved energy term
    energy = tf.square(eng_pos) + tf.exp(-eng_neg)

    # PMI-based loss
    pmiLoss = energy

    # Contrastive Loss
    squared_diff = tf.square(learned_node_features_from - learned_node_features_to)

    # Compute the Euclidean distance with numerical stability
    distance = tf.sqrt(tf.reduce_sum(squared_diff, axis=1) + epsilon)

    # Compute the contrastive loss
    contrastive_loss = y_true_class * tf.square(distance) + (1 - y_true_class) * tf.square(tf.maximum(0.0, margin - distance))

    # Combine the losses with explicit weighting
    combined_loss = alpha * tf.reduce_mean(pmiLoss) + beta * tf.reduce_mean(contrastive_loss)

    return combined_loss



def train_model(model, inputs_all, labels, num_epochs, batch_size):
    # Define the optimizer
    optimizer = tf.keras.optimizers.Adam(learning_rate=1e-5)
    tf.config.run_functions_eagerly(True)

    for epoch in range(num_epochs):
        with tf.GradientTape() as tape:
            # Forward pass
            outputs = model(inputs_all)
            # Compute loss
            loss = pmi_loss_function(labels, outputs)

        gradients = tape.gradient(loss, model.trainable_variables)
        # Update weights
        optimizer.apply_gradients(zip(gradients, model.trainable_variables))



        print(f"Epoch {epoch + 1}, Loss: {loss.numpy()}")

def compute_dist_max_and_argmax_old(graph):
    """
    Compute dist_max and dist_argmax from a NetworkX graph.

    Args:
        graph (nx.Graph): A NetworkX graph object.

    Returns:
        dist_max (tf.Tensor): A tensor of shape [num_nodes, 1] containing the maximum distance from each node.
        dist_argmax (tf.Tensor): A tensor of shape [num_nodes, 1] containing the node index that achieves the maximum distance.
    """
    # Ensure the graph has nodes
    if graph.number_of_nodes() == 0:
        raise ValueError("The graph must contain at least one node.")

    # Compute shortest path lengths between all pairs of nodes
    shortest_paths = dict(nx.shortest_path_length(graph))

    # Number of nodes in the graph
    num_nodes = graph.number_of_nodes()

    # Get the list of nodes in the graph
    nodes = list(graph.nodes())

    # Initialize the distance matrix
    dist_matrix = np.zeros((num_nodes, num_nodes), dtype=np.float32)

    # Fill the distance matrix with shortest path lengths
    for i in range(num_nodes):
        for j in range(num_nodes):
            # Use node indices from the graph
            source_node = nodes[i]
            target_node = nodes[j]
            dist_matrix[i, j] = shortest_paths.get(source_node, {}).get(target_node, np.inf)  # Use np.inf for unreachable nodes

    # Compute dist_max and dist_argmax
    dist_max = np.max(dist_matrix, axis=1)  # Maximum distance from each node
    dist_argmax = np.argmax(dist_matrix, axis=1)  # Node index that achieves the maximum distance

    # Convert to TensorFlow tensors
    dist_max = tf.convert_to_tensor(dist_max, dtype=tf.float32)
    dist_argmax = tf.convert_to_tensor(dist_argmax, dtype=tf.float32)

    # Expand dimensions to match the expected input shape [num_nodes, 1]
    dist_max = tf.expand_dims(dist_max, axis=1)
    dist_argmax = tf.expand_dims(dist_argmax, axis=1)

    return dist_max, dist_argmax


def compute_dist_max_and_argmax(graph, c=0.5):
    """
    Compute dist_max and dist_argmax for a given NetworkX graph using TensorFlow.

    Args:
        graph (nx.Graph): A NetworkX graph object.
        c (float): Parameter controlling the number of anchorsets.

    Returns:
        dist_max (tf.Tensor): A tensor of shape [num_nodes, num_anchorsets] containing the maximum distance from each node to any node in each anchorset.
        dist_argmax (tf.Tensor): A tensor of shape [num_nodes, num_anchorsets] containing the node index in the anchorset that achieves the maximum distance.
    """
    # Step 1: Compute the shortest path lengths between all pairs of nodes
    num_nodes = graph.number_of_nodes()
    nodes = list(graph.nodes())  # Get the list of nodes in the graph

    # Compute shortest path lengths
    dists_dict = dict(nx.all_pairs_shortest_path_length(graph))

    # Convert shortest path lengths to a distance matrix (inverse of shortest path length)
    dists_array = np.zeros((num_nodes, num_nodes), dtype=np.float32)
    for i in range(num_nodes):
        node_i = nodes[i]  # Get the actual node index
        shortest_dist = dists_dict.get(node_i, {})  # Get the shortest paths for node_i
        for j in range(num_nodes):
            node_j = nodes[j]  # Get the actual node index
            dist = shortest_dist.get(node_j, -1)  # Get the shortest path length
            if dist != -1:
                dists_array[i, j] = 1 / (dist + 1)  # Inverse of shortest path length

    # Convert distance matrix to a TensorFlow tensor
    dists = tf.convert_to_tensor(dists_array, dtype=tf.float32)

    # Step 2: Generate random anchorsets
    def get_random_anchorset(n, c=0.5):
        m = int(np.log2(n))
        copy = int(c * m)
        anchorset_id = []
        for i in range(m):
            anchor_size = int(n / np.exp2(i + 1))
            for j in range(copy):
                anchorset_id.append(np.random.choice(n, size=anchor_size, replace=False))
        return anchorset_id

    anchorset_id = get_random_anchorset(num_nodes, c=c)

    # Step 3: Compute dist_max and dist_argmax
    def get_dist_max(anchorset_id, dist):
        num_nodes = dist.shape[0]
        num_anchorsets = len(anchorset_id)

        # Initialize dist_max and dist_argmax tensors
        dist_max = tf.zeros((num_nodes, num_anchorsets), dtype=tf.float32)
        dist_argmax = tf.zeros((num_nodes, num_anchorsets), dtype=tf.int32)

        for i in range(num_anchorsets):
            temp_id = tf.convert_to_tensor(anchorset_id[i], dtype=tf.int32)
            dist_temp = tf.gather(dist, temp_id, axis=1)  # Shape: [num_nodes, anchor_size]

            # Compute dist_max_temp and dist_argmax_temp
            dist_max_temp = tf.reduce_max(dist_temp, axis=-1)  # Shape: [num_nodes]
            dist_argmax_temp = tf.argmax(dist_temp, axis=-1, output_type=tf.int32)  # Shape: [num_nodes]

            # Gather the node indices from temp_id using dist_argmax_temp
            updates_argmax = tf.gather(temp_id, dist_argmax_temp)  # Shape: [num_nodes]

            # Update dist_max and dist_argmax
            dist_max = tf.tensor_scatter_nd_update(
                dist_max,
                indices=[[j, i] for j in range(num_nodes)],  # Indices for all nodes in the current anchorset
                updates=dist_max_temp  # Updates for all nodes in the current anchorset
            )
            dist_argmax = tf.tensor_scatter_nd_update(
                dist_argmax,
                indices=[[j, i] for j in range(num_nodes)],  # Indices for all nodes in the current anchorset
                updates=updates_argmax  # Updates for all nodes in the current anchorset
            )

        return dist_max, dist_argmax

    dist_max, dist_argmax = get_dist_max(anchorset_id, dists)

    return dist_max, dist_argmax
