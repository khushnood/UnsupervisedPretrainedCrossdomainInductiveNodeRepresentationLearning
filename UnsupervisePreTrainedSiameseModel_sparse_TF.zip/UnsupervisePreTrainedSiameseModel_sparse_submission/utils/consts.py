TLP = 'temporal_link_prediction'
NC = 'node_classification'
TLPXYZ = 'temporal_link_prediction_just_garbage'
REG = 'Regression for popularity prediction'
