import tensorflow as tf

def mutual_information_loss(learned_node_features_from_node, learned_node_features_to_node, binary_label):
    """
    Computes Mutual Information (MI) loss for self-supervised graph learning.

    Args:
        learned_node_features_from_node (tf.Tensor): Source node embeddings (shape: [batch_size, embed_dim])
        learned_node_features_to_node (tf.Tensor): Target node embeddings (shape: [batch_size, embed_dim])
        binary_label (tf.Tensor): Binary labels (shape: [batch_size])

    Returns:
        tf.Tensor: Scalar loss value.
    """
    # Compute similarity score using dot product
    similarity_score = tf.reduce_sum(learned_node_features_from_node * learned_node_features_to_node, axis=1)

    # Ensure binary_label has the correct shape
    binary_label = tf.reshape(binary_label, shape=[-1])  # Ensure it's 1D

    # Check if shapes match
    if similarity_score.shape != binary_label.shape:
        print(f"Shape Mismatch: similarity_score {similarity_score.shape}, binary_label {binary_label.shape}")
        binary_label = tf.reshape(binary_label, similarity_score.shape)  # Force reshape if necessary

    # Compute MI loss (Binary Cross-Entropy)
    loss = tf.nn.sigmoid_cross_entropy_with_logits(labels=binary_label, logits=similarity_score)

    # Return mean loss
    return tf.reduce_mean(loss)


