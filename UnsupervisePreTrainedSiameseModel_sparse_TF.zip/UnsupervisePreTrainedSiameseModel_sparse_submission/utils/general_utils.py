import pickle as pickle
import pickle as pickle5


def save_object(obj, filename):
    with open(filename, 'wb') as output:
        pickle.dump(obj, output, pickle.HIGHEST_PROTOCOL)


def load_object(filename):
    try:
        with open(filename, 'rb') as input:
            return pickle.load(input)
    except:
        with open(filename, 'rb') as input:
            return pickle.load(input)


