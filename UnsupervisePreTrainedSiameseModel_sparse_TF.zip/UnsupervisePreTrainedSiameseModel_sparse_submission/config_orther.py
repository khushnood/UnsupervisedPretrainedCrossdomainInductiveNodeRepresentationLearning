import platform
from os.path import join
from datetime import datetime
from utils.consts import TLP, NC

experiment_name = 'AfterNSStrategy'
time_now = datetime.now().strftime('%y%m%d')

params = {
'results_path': join(r"../results", f"{platform.node()}_{time_now}_{experiment_name}"),
'datasets': {'PPI','COLLMN','MITC','EUEMAIL','DPPIN-Tarassov','DPPIN-Krogan_LCMS','ESMUI','FBWP','DPPIN-Tarassov','ARXHEPCOLL','APSCIT','FBFS','DIGV','ARXCIT','DPPIN-Gavin'},
'datasets': {'PPI','EUEMAIL','COLLMN','ARXCIT','FBWP','UCI'}, #New dataset ke liye you have change here the directory name should be the same as in data folder. If anydataset creates a problem with some models while optmization you can remove from the list or run one by one by un-commenting the following line.
'datasets': {'UCI','SocialEvo','enron','FBFS','SDFC','DBLPCOLL','ESMUI','PPI','EUEMAIL','COLLMN','MITC','ARXCIT','FBWP'},
'datasets': {'DPPIN-Babu','DPPIN-Breitkreutz','DPPIN-Gavin','DPPIN-Hazbun','DPPIN-Ho','DPPIN-Ito','DPPIN-Krogan_LCMS','DPPIN-Krogan_MALDI','DPPIN-Lambert','DPPIN-Uetz','DPPIN-Yu','DPPIN-Tarassov'},
'datasets': {'PPI'},
'dataset': 'MITC',
'task': TLP,
'test_size': 0.2,
'train_skip':None,  # down sample the training set
'model_name':'',
'all_models':{'dgnnsiam','temp_gcn','dynnode2vec','dgnn','tnodeembed'}, #dgnn, temp_gcn,dynnode2vec, dgnnsiam :you have to run three models here one by one: dgnnsiam, dynnode2vec, and temp_gcn.
'all_models':{'tnodeembed'},
'n2vargs': {'workers': 4},
'keras_args':
    {'batch_size': 64,
     'nb_epoch': 10,
     'nb_worker': 4}
}

params2 = {
'results_path': join(r"../results", f"{platform.node()}_{time_now}_{experiment_name}"),
'dataset': 'PPI',
'task': TLP,#TLP, NC
'test_size': 0.2,
'train_skip': 100,  # down sample the training set
'n2vargs': {'workers': 4},
'keras_args':
    {'batch_size': 64,
     'nb_epoch': 10,
     'nb_worker': 4}
}
