from math import ceil

import models
import loader

from metrics import get_metrics

import numpy as np

import os
from os.path import join, exists
import gc

import tensorflow as tf
from tensorflow.python.client import device_lib

from datetime import datetime
import argparse
experiment_name = 'WithResidualJan2025'
time_now = datetime.now().strftime('%y%m')

from os.path import join
from datetime import datetime
from utils.consts import TLP
#from visualization.PlottingEmbeddings import  ,plot_embedding,plot_embedding_single_file_tsne,plot_embedding_single_file_seaborn
from visualization.EvaluatingEmbedding import evaluate_dyn_embeddings
def parse_arguments():

    parser = argparse.ArgumentParser(description="Parse command line arguments.")

    # Add arguments with default values from the configuration dictionary
    parser.add_argument('--results_path', type=str, default=f'../results/{experiment_name}',
                        help='Path to save results. Default:../results')



    parser.add_argument('--task', type=str, default=TLP,
                        help='Task type (e.g., TLP). Default: {}')

    parser.add_argument('--test_size', type=float, default=0.2,
                        help='Test set size as a fraction of total data. Default: 0.2')


    #
    parser.add_argument('--model_name', type=str, default='dgnnsiam',
                        help='Name of the model.')

    parser.add_argument('--batch_size', type=int, default=64,
                        help='Batch size for training. Default')

    parser.add_argument('--nb_epoch', type=int, default=200,
                        help='Number of epochs for training. Default:')
    parser.add_argument('--datasets', nargs='*', default={'BIRDN','MITC'},
                        help='LYONSCHOOLCONTACT,BABOONINTERACTION,BIRDN, MITC , DPPIN-Lambert, SDFC, SocialEvo,enron, UCI')
    parser.add_argument('--all_models', type=str, default={'dgnnsiam'},
                        help='')
    parser.add_argument('--num_itr', type=int, default=1,
                        help='')
    parser.add_argument('--pretrained', type=bool, default=0 ,
                        help='')
    parser.add_argument('--transfer', type=bool, default=1,
                        help='')
    parser.add_argument('--model_path', type=str, default='pretrainedModel/pretrainedModel.pkl', # pretrainedModel_withfeatures
                        help='Relative path to save trained model .pkl file')

    parser.add_argument('--ncpu', type=int, default=1,
                        help='number of parellel cpu to apply for different snapshots')

    # Add more arguments as needed  usePretrained isTransferLearning

    # Parse the command line arguments
    args = parser.parse_args()

    # Return the parsed arguments
    return args


def run(args):
    # load graph
    model_name=args.model_name

    graph_nx, dump_folder = loader.load_dataset(args.dataset, 'dump_' + model_name)
    #os.environ["CUDA_VISIBLE_DEVICES"] = "0,1"
    visible_devices = tf.config.experimental.list_physical_devices('GPU')
    print("Visible GPUs:", visible_devices)

    gpus = visible_devices[:2] if len(visible_devices) >= 2 else visible_devices
    print("Using GPUs:", gpus)
    tf.config.experimental.set_visible_devices(gpus, 'GPU')



    task = args.task
    test_size = args.test_size


    model = models.UnsupervisedInductiveGNN(graph_nx, task=task, dump_folder=dump_folder, test_size=test_size, model_name=model_name, \
                                            align=True, dataset_name=args.dataset,is_pretrained=args.pretrained,is_tranfer_learning=args.transfer,model_path=args.model_path,num_cpu=args.ncpu)


    X, y = model.get_dataset()
    plotEmbedding=True
    if plotEmbedding:

        timess=model.train_time_steps
        evaluate_dyn_embeddings(model.graph_nx,timess,f"{args.dataset}",modelName=model_name)
        print(f"embedding plotted for {args.dataset}")
        #exit(0)

            # Clean up memory
        del model

        del X
        del y

         # Clear the TensorFlow session
        gc.collect()  # Run garbage collection to free up memory

        return ''







    callback = tf.keras.callbacks.EarlyStopping(monitor='loss', patience=5)
    keras_args = {}
    keras_args['callbacks']=[callback]
    keras_args['epochs']=args.nb_epoch
    batch_size = args.batch_size
    steps_per_epoch = ceil(len(X['train']) / batch_size)
    print(f"steps per epoch main: {steps_per_epoch   }")
    usrRNN=True
    if(usrRNN):
        generator = loader.dataset_generator(X['train'], y['train'], model.graph_nx, model.train_time_steps, batch_size=batch_size )

        model.fit_generator(generator, steps_per_epoch, **keras_args)

    static_model = models.StaticModel(task=task)
    generator = loader.dataset_generator(X['train'], y['train'], model.graph_nx, [max(model.train_time_steps)], batch_size=batch_size )

    static_model.fit_generator(generator, steps_per_epoch, **keras_args)
    print("steps_per_epoch",steps_per_epoch)



    temporalNodeEmbd_metrics = {"roc_auc": 0.0, "pr_auc": 0.0, "f1_score": 0.0}
    temporalNodeEmbd_metrics_hist_nre = {"roc_auc": 0.0, "pr_auc": 0.0, "f1_score": 0.0}
    #temporalNodeEmbd_metrics_test_rnd = {"roc_auc": 0.0, "pr_auc": 0.0, "f1_score": 0.0}
    #temporalNodeEmbd_metrics_test_induc_nre = {"roc_auc": 0.0, "pr_auc": 0.0, "f1_score": 0.0}
    steps = ceil(len(X['test']) / batch_size)
    if(usrRNN):
        generator = loader.dataset_generator(X['test'], y['test'], model.graph_nx, model.train_time_steps, batch_size=batch_size, shuffle=False)
        temporalNodeEmbd_metrics = get_metrics(y['test'], model.predict_generator(generator, steps))
        #1- his_nre
        generator = loader.dataset_generator(X['test_hist_nre'], y['test_hist_nre'], model.graph_nx, model.train_time_steps, batch_size=batch_size, shuffle=False)
        temporalNodeEmbd_metrics_hist_nre = get_metrics(y['test_hist_nre'], model.predict_generator(generator, steps))







    generator = loader.dataset_generator(X['test'], y['test'], model.graph_nx, [max(model.train_time_steps)], batch_size=batch_size, shuffle=False)
    staticModel_metrics = get_metrics(y['test'], static_model.predict_generator(generator, steps))
    generator = loader.dataset_generator(X['test_hist_nre'], y['test_hist_nre'], model.graph_nx, [max(model.train_time_steps)], batch_size=batch_size, shuffle=False)
    staticModel_metrics_hist_nre = get_metrics(y['test_hist_nre'], static_model.predict_generator(generator, steps))

    generator = loader.dataset_generator(X['test_rnd'], y['test_rnd'], model.graph_nx, [max(model.train_time_steps)], batch_size=batch_size, shuffle=False)



    result_non=temporalNodeEmbd_metrics['roc_auc'],temporalNodeEmbd_metrics['pr_auc'],temporalNodeEmbd_metrics['f1_score'],staticModel_metrics['roc_auc'],staticModel_metrics['pr_auc'],staticModel_metrics['f1_score']
    result_hist_nre=temporalNodeEmbd_metrics_hist_nre['roc_auc'],temporalNodeEmbd_metrics_hist_nre['pr_auc'],temporalNodeEmbd_metrics_hist_nre['f1_score'],staticModel_metrics_hist_nre['roc_auc'],staticModel_metrics_hist_nre['pr_auc'],staticModel_metrics_hist_nre['f1_score']
    #result_rnd=temporalNodeEmbd_metrics_test_rnd['roc_auc'],temporalNodeEmbd_metrics_test_rnd['pr_auc'],temporalNodeEmbd_metrics_test_rnd['f1_score'],staticModel_metrics_test_rnd['roc_auc'],staticModel_metrics_test_rnd['pr_auc'],staticModel_metrics_test_rnd['f1_score']
    #result_induc_nre=temporalNodeEmbd_metrics_test_induc_nre['roc_auc'],temporalNodeEmbd_metrics_test_induc_nre['pr_auc'],temporalNodeEmbd_metrics_test_induc_nre['f1_score'],staticModel_metrics_test_induc_nre['roc_auc'],staticModel_metrics_test_induc_nre['pr_auc'],staticModel_metrics_test_induc_nre['f1_score']
    print(f'Dynamic Vs Static results for model: \t'+args.model_name+'')
    descriptions = ["AUC:", "AUPR:", "F1-score:", "AUC_static:", "AUPR_static:", "F1-score_static:"]
    print(descriptions)
    np.set_printoptions(precision=6)
    print(f'NS strategy non: {result_non}:')
    print(f'NS strategy hist_nre: {result_hist_nre}:')



    return [np.asarray(result_non),np.asarray(result_hist_nre),dump_folder]


def write_to_file(file_path,strategy, model, result_matr, num_of_experiments):
    from prettytable import PrettyTable


    descriptions = ["AUC", "AUPR", "F1-score", "AUC_static", "AUPR_static", "F1-score_static"]
    table = PrettyTable(descriptions)
    table.title = f"Results using model: {model}, NS strategy: {strategy} and time "+datetime.now().strftime('%y%m%d%h%H%M')
    descriptions_avg = ["AUC_mean", "AUPR_mean", "F1-score_mean", "AUC_static_mean", "AUPR_static_mean", "F1-score_static_mean"]
    descriptions_std = ["AUC_std", "AUPR_std", "F1-score_std", "AUC_static_std", "AUPR_static_std", "F1-score_static_std"]
    np.set_printoptions(precision=5)
    with open(file_path, 'a' if os.path.exists(file_path) else 'w') as file_out:
        average_result = np.sum(result_matr, axis=0) / num_of_experiments
        std_deviation = np.std(result_matr, axis=0)

        for idx, lst in enumerate(result_matr.tolist()):
            table.add_row(lst)

        table.add_row(descriptions_avg)

        table.add_row(average_result)
        table.add_row(descriptions_std)
        table.add_row(std_deviation)
        file_out.write(table.get_string())
    print(table.get_string())


# CUDA_VISIBLE_DEVICES="1,2" python main.py
# CUDA_VISIBLE_DEVICES=" " python main.py
if __name__ == '__main__':

    args=parse_arguments()
    print(f"cmd args: {args}")
    #tf.compat.v1.enable_eager_execution()
    #tf.config.experimental_run_functions_eagerly(True)

    numOfExperiments=args.num_itr

    isDelete=False

    results_path = args.results_path
    if not os.path.exists(results_path):
        os.makedirs(results_path)

    for model in (args.all_models):
        args.model_name=model

        for dataset in (args.datasets):
            args.dataset=dataset
            resultMatr_non=np.zeros((numOfExperiments, 6), dtype='float')
            result_hist_nre=np.zeros((numOfExperiments, 6), dtype='float')

            result_strategy_non_file=join(results_path, dataset + '_result_' + args.model_name+ '_non.txt')
            result_strategy_hist_nre_file=join(results_path, dataset + '_result_' + args.model_name + '_hist_nre.txt')

            result_strategy_all_file=join(results_path, dataset + '_result_' + args.model_name + '.txt')

            for expr in range(0,numOfExperiments):
                print("experimental iteraction",expr+1,": datatset ",dataset," model name: ",model)
                np.random.seed(786)

                tf.compat.v1.set_random_seed(786)

                dump_folder = 'dump_'+model
                init_path = join(os.path.abspath(os.pardir),'data',dataset,dump_folder, 'init.emb')
                if os.path.exists(init_path) and isDelete:
                    print(init_path)
                    os.remove(init_path);
                results=run(args)



def get_available_gpus():
    local_device_protos = device_lib.list_local_devices()
    return [x.name for x in local_device_protos if x.device_type == 'GPU']


