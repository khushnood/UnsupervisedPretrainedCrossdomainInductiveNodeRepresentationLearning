
Abbas, K., Dong, S., Abbasi, A., & Tang, Y. Cross-Domain Inductive Applications with Unsupervised (Dynamic) Graph Neural Networks (Gnn): Leveraging Siamese Gnn and Energy-Based Pmi Optimization. Available at SSRN 4878938.

*Requirement**

Python >=3.7

tensorflow==2.5 compatible

pip install scipy==1.7.3 networkx==2.3 tqdm==4.40.0 pandas==1.3.2 Keras==2.3.1 matplotlib==3.5.2 torch==1.9.0 node2vec==0.4.3 sklearn==0.0 prettytable qc-procrustes


usage for training for first time

python main.py --datasets 'THCN' --pretrained 0 --model_path 'pretrainedModel_sparse/pretrainedModel.ckpt'


usage for training for using as pretrained

python main.py --datasets 'THCN' --pretrained 1 --model_path 'pretrainedModel_sparse/pretrainedModel.ckpt'

For transfor learning 
python main.py --datasets 'THCN' --pretrained transfer --model_path 'pretrainedModel_sparse/pretrainedModel.ckpt'

for using your own data see the loader/dataset_loader.py/load_dataset() function.
For more options for parellel execution use --ncpu 10.. make sure you have enough RAM to generate the embedding parelllaly for different snapshots.